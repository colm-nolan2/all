# IQMS Documentation Repository

Welcome to the official documentation repository for the IQMS project! This repository serves as the central hub for storing project documentation, including diagrams and potentially other resources like analysis documents, user guides, and more.

## Directory Structure

- 📁 **Diagrams**: This directory contains diagrams documenting the application architecture, following the C4 model and using [PlantUML](https://plantuml.com/) as the Diagram as Code tool.

## C4 Model

The application architecture is documented using the C4 model. The C4 model provides a clear and concise way to represent the architecture of software systems.

The C4 model was created as a way to help software development teams describe and communicate software architecture, both during up-front design sessions and when retrospectively documenting an existing codebase. It's a way to create maps of your code, at various levels of detail, in the same way you would use something like Google Maps to zoom in and out of an area you are interested in.

For more information on the C4 model, refer to the official [C4 Model website](https://c4model.com/).

## Contributing

We welcome contributions to enhance the documentation! If you have any suggestions, improvements, or additional resources, feel free to open an issue or submit a pull request.
