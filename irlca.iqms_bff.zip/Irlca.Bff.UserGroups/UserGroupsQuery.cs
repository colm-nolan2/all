﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.UserGroups;

public class UserGroupsQuery
{
    
}
