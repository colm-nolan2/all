﻿using System.Security.Claims;

namespace Irlca.Bff.Gateway.Extensions;

internal static class ClaimsPrincipalExtensions
{
    internal static bool HasPermission(this ClaimsPrincipal principal, string permission) =>
        principal.HasClaim("permissions", permission);
}
