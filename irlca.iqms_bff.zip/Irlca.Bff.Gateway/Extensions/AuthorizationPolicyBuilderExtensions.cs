﻿using Microsoft.AspNetCore.Authorization;

namespace Irlca.Bff.Gateway.Extensions;

internal static class AuthorizationPolicyBuilderExtensions
{
    internal static AuthorizationPolicyBuilder RequirePermission(this AuthorizationPolicyBuilder builder, string permission) =>
        builder.RequireClaim("permissions", permission);
}
