﻿#pragma warning disable CA1506

using System.ComponentModel.DataAnnotations;
using HotChocolate.Diagnostics;
using HotChocolate.Language;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Gateway.Authorization.Requirements.ViewChecklist;
using Irlca.Bff.Gateway.Authorization.Requirements.ViewIssue;
using Irlca.Bff.Gateway.Authorization.Requirements.ViewIssueAssessmentSupportingData;
using Irlca.Bff.Iqms;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace Irlca.Bff.Gateway.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddGraphQLGateway(this IServiceCollection services, IConfiguration configuration, IHostEnvironment environment)
    {
        services.AddOptions<ConnectionStringsOptions>()
            .Bind(configuration.GetSection(ConnectionStringsOptions.SectionName))
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddSingleton(sp => sp.GetRequiredService<IOptions<ConnectionStringsOptions>>().Value);

        services
            .AddHttpClient(
                "Assets",
                (sp, c) => c.BaseAddress = new Uri(sp.GetRequiredService<ConnectionStringsOptions>().IqmsApiAssetsGraphQLUrl))
            .AddHeaderPropagation();
        services
            .AddHttpClient(
                "InspectionReports",
                (sp, c) => c.BaseAddress = new Uri(sp.GetRequiredService<ConnectionStringsOptions>().IqmsApiInspectionReportsGraphQLUrl))
            .AddHeaderPropagation();
        services
            .AddHttpClient(
                "Inspections",
                (sp, c) => c.BaseAddress = new Uri(sp.GetRequiredService<ConnectionStringsOptions>().IqmsApiInspectionsGraphQLUrl))
            .AddHeaderPropagation();
        services
            .AddHttpClient(
                "Requests",
                (sp, c) => c.BaseAddress = new Uri(sp.GetRequiredService<ConnectionStringsOptions>().IqmsApiRequestsGraphQLUrl))
            .AddHeaderPropagation();
        services
            .AddHttpClient(
                "Checklists",
                (sp, c) => c.BaseAddress = new Uri(sp.GetRequiredService<ConnectionStringsOptions>().IqmsApiChecklistsGraphQLUrl))
            .AddHeaderPropagation();
        services
            .AddHttpClient(
                "Scribes",
                (sp, c) => c.BaseAddress = new Uri(sp.GetRequiredService<ConnectionStringsOptions>().IqmsApiScribesGraphQLUrl))
            .AddHeaderPropagation();

        services.AddAuthorizationBuilder()
            .AddPolicy(AuthorizationPolicies.ViewAssets, b => b.RequirePermission(IqmsPermissions.ViewAssets))
            .AddPolicy(AuthorizationPolicies.ViewComments, b => b.RequirePermission(IqmsPermissions.ViewComments))
            .AddPolicy(AuthorizationPolicies.ViewUsers, b => b.RequirePermission(IqmsPermissions.ViewUsers))
            .AddPolicy(AuthorizationPolicies.ViewUserGroups, b => b.RequirePermission(IqmsPermissions.ViewUserGroups))
            .AddPolicy(AuthorizationPolicies.ViewEntities, b => b.RequirePermission(IqmsPermissions.ViewEntities))
            .AddPolicy(AuthorizationPolicies.ViewRoles, b => b.RequirePermission(IqmsPermissions.ViewRoles))
            .AddPolicy(AuthorizationPolicies.ViewDepartments, b => b.RequirePermission(IqmsPermissions.ViewDepartments))
            .AddPolicy(AuthorizationPolicies.ViewCompanyRoles, b => b.RequirePermission(IqmsPermissions.ViewCompanyRoles))
            .AddPolicy(AuthorizationPolicies.ViewProcessRoles, b => b.RequirePermission(IqmsPermissions.ViewProcessRoles))
            .AddPolicy(AuthorizationPolicies.ViewInspections, b => b.RequirePermission(IqmsPermissions.ViewInspections))
            .AddPolicy(AuthorizationPolicies.ViewInspectionIssues, b => b.RequirePermission(IqmsPermissions.ViewInspectionIssues))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsSettings, b => b.RequirePermission(IqmsPermissions.ViewInspectionsSettings))
            .AddPolicy(AuthorizationPolicies.ViewInspectionPlanningTeam, b => b.RequirePermission(IqmsPermissions.ViewInspectionPlanningTeam))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsDistributionList, b => b.RequirePermission(IqmsPermissions.ViewInspectionsDistributionList))
            .AddPolicy(AuthorizationPolicies.ViewInspectionEvents, b => b.RequirePermission(IqmsPermissions.ViewInspectionEvents))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsInspectorReport, b => b.RequirePermission(IqmsPermissions.ViewInspectionsInspectorReport))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsPreInspectionRequests, b => b.RequirePermission(IqmsPermissions.ViewInspectionsPreInspectionRequests))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsPreinspectionRequestsAttachments, b => b.RequirePermission(IqmsPermissions.ViewInspectionsPreinspectionRequestsAttachments))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsPreinspectionRequestsChecklistExecutions, b => b.RequirePermission(IqmsPermissions.ViewInspectionsPreinspectionRequestsChecklistExecutions))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsPreinspectionRequestsComments, b => b.RequirePermission(IqmsPermissions.ViewInspectionsPreinspectionRequestsComments))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsPreinspectionChecklistExecutions, b => b.RequirePermission(IqmsPermissions.ViewInspectionsPreinspectionChecklistExecutions))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsInspectionChecklistExecutions, b => b.RequirePermission(IqmsPermissions.ViewInspectionsInspectionChecklistExecutions))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsReport, b => b.RequirePermission(IqmsPermissions.ViewInspectionsReport))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsInspectorSuggestion, b => b.RequirePermission(IqmsPermissions.ViewInspectionsInspectorSuggestion))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsForReview, b => b.RequirePermission(IqmsPermissions.ViewInspectionsForReview))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsRequest, b => b.RequirePermission(IqmsPermissions.ViewInspectionsRequest))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsRequestComments, b => b.RequirePermission(IqmsPermissions.ViewInspectionsRequestComments))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsRequestAttachments, b => b.RequirePermission(IqmsPermissions.ViewInspectionsRequestAttachments))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsRequestChecklistExecutions, b => b.RequirePermission(IqmsPermissions.ViewInspectionsRequestChecklistExecutions))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsLessonsLearned, b => b.RequirePermission(IqmsPermissions.ViewInspectionsLessonsLearned))
            .AddPolicy(AuthorizationPolicies.ViewInspectionScopeAssets, b => b.RequirePermission(IqmsPermissions.ViewInspectionScopeAssets))
            .AddPolicy(AuthorizationPolicies.ViewInspectionScopeLetter, b => b.RequirePermission(IqmsPermissions.ViewInspectionScopeLetter))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsObservation, b => b.RequirePermission(IqmsPermissions.ViewInspectionsObservation))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsTasks, b => b.RequirePermission(IqmsPermissions.ViewInspectionsTasks))
            .AddPolicy(AuthorizationPolicies.ViewInspectionsFocusAreas, b => b.RequirePermission(IqmsPermissions.ViewInspectionsFocusAreas))
            .AddPolicy(AuthorizationPolicies.ViewChecklists, b => b.AddRequirements(new ViewChecklistRequirement()))
            .AddPolicy(AuthorizationPolicies.ViewChecklistSettings, b => b.RequirePermission(IqmsPermissions.ViewChecklistSettings))
            .AddPolicy(AuthorizationPolicies.ViewIssues, b => b.AddRequirements(new ViewIssueRequirement()))
            .AddPolicy(AuthorizationPolicies.ViewIssuesAssessmentsSupportingData, b => b.AddRequirements(new ViewIssueAssessmentSupportingDataRequirement()))
            .AddPolicy(AuthorizationPolicies.ViewTasksSettings, b => b.RequirePermission(IqmsPermissions.ViewTasksSettings));

        services.AddSingleton<IAuthorizationHandler, ViewIssueAuthorizationHandler>();
        services.AddSingleton<IAuthorizationHandler, ViewIssueAssessmentSupportingDataAuthorizationHandler>();
        services.AddSingleton<IAuthorizationHandler, ViewChecklistAuthorizationHandler>();

        services.AddMemoryCache()
            .AddSha256DocumentHashProvider(HashFormat.Hex);

        services.AddGraphQLServer()
            .AddAuthorization()
            .AllowIntrospection(environment.IsDevelopment())
            .ModifyRequestOptions(
                o =>
                {
                    o.Complexity.Enable = true;
                    o.Complexity.MaximumAllowed = 1500;
                    o.Complexity.ApplyDefaults = true;
                    o.Complexity.DefaultComplexity = 1;
                    o.Complexity.DefaultResolverComplexity = 5;
                })
            .ModifyOptions(
                o =>
                {
                    o.RemoveUnreachableTypes = true;
                    o.RemoveUnusedTypeSystemDirectives = true;
                })
            .AddLocalSchema(Consts.SchemaName, ignoreRootTypes: true)
            .AddRemoteSchema("Assets", ignoreRootTypes: true)
            .AddRemoteSchema("Checklists", ignoreRootTypes: true)
            .AddRemoteSchema("InspectionReports", ignoreRootTypes: true)
            .AddRemoteSchema("Inspections", ignoreRootTypes: true)
            .AddRemoteSchema("Requests", ignoreRootTypes: true)
            .AddRemoteSchema("Scribes", ignoreRootTypes: true)
            .RenameType("ApplyPolicy", "Assets_ApplyPolicy", "Assets")
            .RenameType("ApplyPolicy", "Checklists_ApplyPolicy", "Checklists")
            .RenameType("ApplyPolicy", "InspectionReports_ApplyPolicy", "InspectionReports")
            .RenameType("ApplyPolicy", "Inspections_ApplyPolicy", "Inspections")
            .RenameType("ApplyPolicy", "Requests_ApplyPolicy", "Requests")
            .RenameType("ApplyPolicy", "Scribes_ApplyPolicy", "Scribes")
            .AddQueryType(d => d.Name("Query"))
            .AddMutationType(d => d.Name("Mutation"))
            .AddGatewayTypes()
            .AddTypeExtensionsFromFile(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Query.graphql"))
            .AddTypeExtensionsFromFile(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mutation.graphql"))
            .AddInstrumentation(
                b =>
                {
                    b.IncludeDataLoaderKeys = true;
                    b.IncludeDocument = true;
                    b.RequestDetails = RequestDetails.All;
                    b.Scopes = ActivityScopes.All;
                })
            .AddApolloTracing()
            .UseAutomaticPersistedQueryPipeline()
            .AddInMemoryQueryStorage();

        return services;
    }

    private sealed class ConnectionStringsOptions
    {
        public const string SectionName = "ConnectionStrings";

        [Required]
        [MinLength(1)]
        [Url]
        public string IqmsApiAssetsGraphQLUrl { get; set; } = string.Empty;

        [Required]
        [MinLength(1)]
        [Url]
        public string IqmsApiInspectionReportsGraphQLUrl { get; set; } = string.Empty;

        [Required]
        [MinLength(1)]
        [Url]
        public string IqmsApiInspectionsGraphQLUrl { get; set; } = string.Empty;

        [Required]
        [MinLength(1)]
        [Url]
        public string IqmsApiRequestsGraphQLUrl { get; set; } = string.Empty;

        [Required]
        [MinLength(1)]
        [Url]
        public string IqmsApiChecklistsGraphQLUrl { get; set; } = string.Empty;

        [Required]
        [MinLength(1)]
        [Url]
        public string IqmsApiScribesGraphQLUrl { get; set; } = string.Empty;
    }
}
