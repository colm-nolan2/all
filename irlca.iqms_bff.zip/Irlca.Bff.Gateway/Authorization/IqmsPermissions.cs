﻿namespace Irlca.Bff.Gateway.Authorization;

public static class IqmsPermissions
{
    public const string ViewAssets = "iqms.assets.view";

    public const string ViewComments = "irlca.comments.view";

    public const string ViewUsers = "tm.users.view";

    public const string ViewUserGroups = "iqms.users.groups.view";

    public const string ViewEntities = "tm.entities.view";
    public const string ViewDepartments = "tm.departments.view";
    public const string ViewCompanyRoles = "iqms.company.roles.view";
    public const string ViewProcessRoles = "iqms.process.roles.view";

    public const string ViewRoles = "tm.roles.view";

    public const string ViewInspections = "im.inspections.view";
    public const string ViewInspectionIssues = "im.inspections.issues.view";
    public const string ViewInspectionIssuesAssessmentsComments = "im.inspections.issues.assessments.comments.view";
    public const string ViewInspectionIssuesAssessmentsSupportingData = "im.inspections.issues.assessments.supportingdata.view";
    public const string ViewInspectionIssuesAssessmentsTasks = "im.inspections.issues.assessments.tasks.view";
    public const string ViewInspectionsSettings = "im.inspections.settings.view";
    public const string ViewInspectionPlanningTeam = "im.inspections.planning.team.view";
    public const string ViewInspectionEvents = "im.inspections.events.view";
    public const string ViewInspectionsDistributionList = "im.inspections.planning.distributionlist.view";
    public const string ViewInspectionsInspectorReport = "im.inspections.postinspection.inspectorreport.view";
    public const string ViewInspectionsPreInspectionRequests = "im.inspections.preinspection.requests.view";
    public const string ViewInspectionsPreinspectionRequestsAttachments = "im.inspections.preinspection.requests.attachments.view";
    public const string ViewInspectionsPreinspectionRequestsChecklistExecutions = "im.inspections.inspection.requests.checklistexecutions.view";
    public const string ViewInspectionsPreinspectionRequestsComments = "im.inspections.preinspection.requests.comments.view";
    public const string ViewInspectionsPreinspectionChecklistExecutions = "im.inspections.preinspection.checklistexecutions.view";
    public const string ViewInspectionsInspectionChecklistExecutions = "im.inspections.inspection.checklistexecutions.view";
    public const string ViewInspectionsReport = "im.inspections.inspection.reports.view";
    public const string ViewInspectionsForReview = "im.inspections.inspection.reviews.view";
    public const string ViewInspectionsInspectorSuggestion = "im.inspections.inspection.suggestions.view";
    public const string ViewInspectionsRequest = "im.inspections.inspection.requests.view";
    public const string ViewInspectionsRequestAttachments = "im.inspections.inspection.requests.attachments.view";
    public const string ViewInspectionsRequestComments = "im.inspections.inspection.requests.comments.view";
    public const string ViewInspectionsRequestChecklistExecutions = "im.inspections.inspection.requests.checklistexecutions.view";
    public const string ViewInspectionsLessonsLearned = "im.inspections.closeout.lessonslearned.view";
    public const string ViewInspectionScopeAssets = "im.inspections.planning.assets.view";
    public const string ViewInspectionScopeLetter = "im.inspections.planning.inspectionletter.view";
    public const string ViewInspectionsObservation = "im.inspections.postinspection.observations.view";
    public const string ViewInspectionsTasks = "im.inspections.tasks.view";
    public const string ViewInspectionsFocusAreas = "im.inspections.inspection.focusareas.view";

    public const string ViewChecklists = "iqms.checklists.view";
    public const string ViewChecklistSettings = "iqms.checklists.settings.view";

    public const string ViewIssues = "irlca.issues.view";

    public const string ViewTasksSettings = "irlca.tasks.settings.view";
}
