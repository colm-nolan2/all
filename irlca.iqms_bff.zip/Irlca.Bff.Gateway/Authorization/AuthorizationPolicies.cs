﻿namespace Irlca.Bff.Gateway.Authorization;

public static class AuthorizationPolicies
{
    public const string ViewAssets = nameof(ViewAssets);

    public const string ViewComments = nameof(ViewComments);

    public const string ViewUsers = nameof(ViewUsers);

    public const string ViewUserGroups = nameof(ViewUserGroups);

    public const string ViewEntities = nameof(ViewEntities);
    public const string ViewDepartments = nameof(ViewDepartments);
    public const string ViewCompanyRoles = nameof(ViewCompanyRoles);
    public const string ViewProcessRoles = nameof(ViewProcessRoles);

    public const string ViewRoles = nameof(ViewRoles);

    public const string ViewInspections = nameof(ViewInspections);
    public const string ViewInspectionIssues = nameof(ViewInspectionIssues);
    public const string ViewInspectionsSettings = nameof(ViewInspectionsSettings);
    public const string ViewInspectionPlanningTeam = nameof(ViewInspectionPlanningTeam);
    public const string ViewInspectionsDistributionList = nameof(ViewInspectionsDistributionList);
    public const string ViewInspectionEvents = nameof(ViewInspectionEvents);
    public const string ViewInspectionsInspectorReport = nameof(ViewInspectionsInspectorReport);
    public const string ViewInspectionsPreInspectionRequests = nameof(ViewInspectionsPreInspectionRequests);
    public const string ViewInspectionsPreinspectionRequestsAttachments = nameof(ViewInspectionsPreinspectionRequestsAttachments);
    public const string ViewInspectionsPreinspectionRequestsChecklistExecutions = nameof(ViewInspectionsPreinspectionRequestsChecklistExecutions);
    public const string ViewInspectionsPreinspectionRequestsComments = nameof(ViewInspectionsPreinspectionRequestsComments);
    public const string ViewInspectionsPreinspectionChecklistExecutions = nameof(ViewInspectionsPreinspectionChecklistExecutions);
    public const string ViewInspectionsInspectionChecklistExecutions = nameof(ViewInspectionsInspectionChecklistExecutions);
    public const string ViewInspectionsReport = nameof(ViewInspectionsReport);
    public const string ViewInspectionsForReview = nameof(ViewInspectionsForReview);
    public const string ViewInspectionsInspectorSuggestion = nameof(ViewInspectionsInspectorSuggestion);
    public const string ViewInspectionsRequest = nameof(ViewInspectionsRequest);
    public const string ViewInspectionsRequestAttachments = nameof(ViewInspectionsRequestAttachments);
    public const string ViewInspectionsRequestComments = nameof(ViewInspectionsRequestComments);
    public const string ViewInspectionsRequestChecklistExecutions = nameof(ViewInspectionsRequestChecklistExecutions);
    public const string ViewInspectionsLessonsLearned = nameof(ViewInspectionsLessonsLearned);
    public const string ViewInspectionScopeAssets = nameof(ViewInspectionScopeAssets);
    public const string ViewInspectionScopeLetter = nameof(ViewInspectionScopeLetter);
    public const string ViewInspectionsObservation = nameof(ViewInspectionsObservation);
    public const string ViewInspectionsTasks = nameof(ViewInspectionsTasks);
    public const string ViewInspectionsFocusAreas = nameof(ViewInspectionsFocusAreas);

    public const string ViewChecklists = nameof(ViewChecklists);
    public const string ViewChecklistSettings = nameof(ViewChecklistSettings);

    public const string ViewIssues = nameof(ViewIssues);
    public const string ViewIssuesAssessmentsSupportingData = nameof(ViewIssuesAssessmentsSupportingData);

    public const string ViewTasksSettings = nameof(ViewTasksSettings);
}
