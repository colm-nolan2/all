﻿using Microsoft.AspNetCore.Authorization;

namespace Irlca.Bff.Gateway.Authorization.Requirements.ViewIssueAssessmentSupportingData;

public class ViewIssueAssessmentSupportingDataRequirement : IAuthorizationRequirement
{
}
