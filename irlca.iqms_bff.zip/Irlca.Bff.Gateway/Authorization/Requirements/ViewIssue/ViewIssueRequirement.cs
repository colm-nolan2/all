﻿using Microsoft.AspNetCore.Authorization;

namespace Irlca.Bff.Gateway.Authorization.Requirements.ViewIssue;

public class ViewIssueRequirement : IAuthorizationRequirement
{
}
