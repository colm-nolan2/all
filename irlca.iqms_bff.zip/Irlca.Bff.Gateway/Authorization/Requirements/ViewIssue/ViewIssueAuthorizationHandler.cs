﻿using System.Text.RegularExpressions;
using HotChocolate.Resolvers;
using Irlca.Bff.Gateway.Extensions;
using Microsoft.AspNetCore.Authorization;

namespace Irlca.Bff.Gateway.Authorization.Requirements.ViewIssue;

public class ViewIssueAuthorizationHandler : AuthorizationHandler<ViewIssueRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        ViewIssueRequirement requirement)
    {
        if (context.User.HasPermission(IqmsPermissions.ViewIssues))
        {
            context.Succeed(requirement);
            return Task.CompletedTask;
        }

        if (context.Resource is not IMiddlewareContext ctx)
        {
            return Task.CompletedTask;
        }

        var path = ctx.Path.ToString();

        if (Regex.IsMatch(path, "^/inspections?") && context.User.HasPermission(IqmsPermissions.ViewInspectionIssues))
        {
            context.Succeed(requirement);
            return Task.CompletedTask;
        }

        return Task.CompletedTask;
    }
}
