﻿using Microsoft.AspNetCore.Authorization;

namespace Irlca.Bff.Gateway.Authorization.Requirements.ViewChecklist;

public class ViewChecklistRequirement : IAuthorizationRequirement
{
}
