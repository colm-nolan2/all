﻿using Irlca.Bff.Gateway.Extensions;
using Microsoft.AspNetCore.Authorization;

namespace Irlca.Bff.Gateway.Authorization.Requirements.ViewChecklist;

public class ViewChecklistAuthorizationHandler : AuthorizationHandler<ViewChecklistRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        ViewChecklistRequirement requirement)
    {
        if (context.User.HasPermission(IqmsPermissions.ViewChecklists))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}
