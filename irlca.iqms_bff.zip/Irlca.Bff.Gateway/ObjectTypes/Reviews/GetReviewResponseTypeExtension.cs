﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Reviews;

public class GetReviewResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetReviewResponse));

        descriptor
            .Field("topics")
            .Type($"[{nameof(GetAssetResponse)}!]")
            .Directive(new DelegateDirective("assets(ids: $fields:topicIds)", "Assets"));

        descriptor
            .Field("systems")
            .Type($"[{nameof(GetAssetResponse)}!]")
            .Directive(new DelegateDirective("assets(ids: $fields:systemIds)", "Assets"));
    }
}
