﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Assets;

public class GetAssetResponseFunctionalAreaTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetAssetResponseFunctionalArea));

        descriptor.Authorize(AuthorizationPolicies.ViewAssets);
    }
}
