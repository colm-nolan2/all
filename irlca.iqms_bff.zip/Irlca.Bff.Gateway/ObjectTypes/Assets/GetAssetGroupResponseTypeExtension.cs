﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Assets;

public class GetAssetGroupResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetAssetGroupResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewAssets);
    }
}
