﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Comments;

public class GetChildCommentResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetChildCommentResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewComments);
    }
}
