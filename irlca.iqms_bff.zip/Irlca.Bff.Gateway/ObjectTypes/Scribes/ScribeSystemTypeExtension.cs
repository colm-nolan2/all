﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class ScribeSystemTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("ScribeSystem");

        descriptor
            .Field("system")
            .Type($"{nameof(GetAssetResponse)}!")
            .Directive(new DelegateDirective("asset(id: $fields:id)", "Assets"));
    }
}
