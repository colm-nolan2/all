﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class RequestScribeEntryTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("RequestScribeEntry");

        descriptor
            .Field("owner")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:ownerId)", "Iqms"));

        descriptor
            .Field("request")
            .Type($"{nameof(GetRequestResponse)}!")
            .Directive(new DelegateDirective("request(id: $fields:requestId)", "Requests"));
    }
}
