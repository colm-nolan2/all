﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class InspectorSuggestionScribeEntryInspectorTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("InspectorSuggestionScribeEntryInspector");

        descriptor
            .Field("inspector")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:inspectorId)", "Iqms"));

        descriptor
            .Field("inspectionAgency")
            .Type($"{nameof(GetTenantProfileResponse)}!")
            .Directive(new DelegateDirective("tenantProfile(id: $fields:inspectionAgencyId)", "Iqms"));
    }
}
