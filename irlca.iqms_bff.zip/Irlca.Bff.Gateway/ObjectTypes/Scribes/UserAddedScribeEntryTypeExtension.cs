﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class UserAddedScribeEntryTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("UserAddedScribeEntry");

        descriptor
            .Field("user")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:userId)", "Iqms"));
    }
}
