﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class TopicAddedScribeEntryTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("TopicAddedScribeEntry");

        descriptor
            .Field("topic")
            .Type($"{nameof(GetAssetResponse)}!")
            .Directive(new DelegateDirective("asset(id: $fields:topicId)", "Assets"));
    }
}
