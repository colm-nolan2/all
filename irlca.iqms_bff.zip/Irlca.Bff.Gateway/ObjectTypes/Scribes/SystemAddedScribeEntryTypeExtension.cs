﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class SystemAddedScribeEntryTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("SystemAddedScribeEntry");

        descriptor
            .Field("system")
            .Type($"{nameof(GetAssetResponse)}!")
            .Directive(new DelegateDirective("asset(id: $fields:systemId)", "Assets"));
    }
}
