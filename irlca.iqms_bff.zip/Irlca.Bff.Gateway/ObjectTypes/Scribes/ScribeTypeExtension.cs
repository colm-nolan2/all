﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class ScribeTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("Scribe");

        descriptor
            .Field("companyMembers")
            .Type($"[{nameof(GetUserProfileResponse)}!]!")
            .Directive(new DelegateDirective("scribeCompanyMembers(id: $fields:id)", "Iqms"));

        descriptor
            .Field("inspectionAgencyMembers")
            .Type($"[{nameof(GetUserProfileResponse)}!]!")
            .Directive(new DelegateDirective("scribeInspectionAgencyMembers(id: $fields:id)", "Iqms"));
    }
}
