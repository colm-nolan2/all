﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class ReviewScribeEntryTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("ReviewScribeEntry");

        descriptor
            .Field("owner")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:ownerId)", "Iqms"));

        descriptor
            .Field("review")
            .Type($"{nameof(GetReviewResponse)}!")
            .Directive(new DelegateDirective("review(id: $fields:reviewId)", "Iqms"));
    }
}
