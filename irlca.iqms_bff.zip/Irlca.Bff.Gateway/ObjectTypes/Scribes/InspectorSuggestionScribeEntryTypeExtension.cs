﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Scribes;

public class InspectorSuggestionScribeEntryTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("InspectorSuggestionScribeEntry");

        descriptor
            .Field("inspectorSuggestion")
            .Type($"{nameof(GetInspectorSuggestionResponse)}!")
            .Directive(new DelegateDirective("inspectorSuggestion(id: $fields:inspectorSuggestionId)", "Iqms"));
    }
}
