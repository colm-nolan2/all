﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Requests;

public class GetRequestResponseScribeRequestTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetRequestResponseScribeRequest));

        descriptor
            .Field("coordinator")
            .Type(nameof(GetUserProfileResponse))
            .Authorize(AuthorizationPolicies.ViewUsers)
            .Directive(new DelegateDirective("findUser(id: $fields:coordinatorId)", "Iqms"));

        descriptor
            .Field("reviewer")
            .Type(nameof(GetUserProfileResponse))
            .Authorize(AuthorizationPolicies.ViewUsers)
            .Directive(new DelegateDirective("findUser(id: $fields:reviewerId)", "Iqms"));

        descriptor
            .Field("attachments")
            .Type($"[{nameof(GetDocumentDetailsResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionsRequestAttachments)
            .Directive(new DelegateDirective("requestAttachments(id: $fields:id)", "Iqms"));

        descriptor
            .Field("comments")
            .Type($"[{nameof(GetCommentResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionsRequestComments)
            .Directive(new DelegateDirective("requestComments(id: $fields:id)", "Iqms"));

        descriptor
            .Field("issues")
            .Type($"[{nameof(GetIssueResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionIssues)
            .Directive(new DelegateDirective("requestIssues(id: $fields:id)", "Iqms"));

        descriptor
            .Field("checklistExecutions")
            .Type($"[{nameof(GetChecklistExecutionResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionsRequestChecklistExecutions)
            .Directive(new DelegateDirective("requestChecklistExecutions(requestId: $fields:id)", "Checklists"));
    }
}
