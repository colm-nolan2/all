﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Requests;

public class GetRequestResponseInterfaceExtension : InterfaceTypeExtension
{
    protected override void Configure(IInterfaceTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetRequestResponse));

        descriptor
            .Field("coordinator")
            .Type(nameof(GetUserProfileResponse))
            .Directive(new DelegateDirective("findUser(id: $fields:coordinatorId)", "Iqms"));

        descriptor
            .Field("reviewer")
            .Type(nameof(GetUserProfileResponse))
            .Directive(new DelegateDirective("findUser(id: $fields:reviewerId)", "Iqms"));

        descriptor
            .Field("attachments")
            .Type($"[{nameof(GetDocumentDetailsResponse)}!]!")
            .Directive(new DelegateDirective("requestAttachments(id: $fields:id)", "Iqms"));

        descriptor
            .Field("comments")
            .Type($"[{nameof(GetCommentResponse)}!]!")
            .Directive(new DelegateDirective("requestComments(id: $fields:id)", "Iqms"));

        descriptor
            .Field("issues")
            .Type($"[{nameof(GetIssueResponse)}!]!")
            .Directive(new DelegateDirective("requestIssues(id: $fields:id)", "Iqms"));

        descriptor
            .Field("checklistExecutions")
            .Type($"[{nameof(GetChecklistExecutionResponse)}!]!")
            .Directive(new DelegateDirective("requestChecklistExecutions(requestId: $fields:id)", "Checklists"));
    }
}
