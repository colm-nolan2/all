﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionSettingsAreaMandatoryRoleResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionSettingsAreaMandatoryRoleResponse));

        descriptor
            .Field("role")
            .Type($"{nameof(GetInspectionAreaRoleResponse)}!")
            .Directive(new DelegateDirective("inspectionAreaRole(areaId: $fields:inspectionAreaId, roleId: $fields:inspectionAreaRoleId)", "Iqms"));
    }
}
