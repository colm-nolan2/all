﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionEventResponseEventFacilityTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionEventResponseEventFacility));

        descriptor
            .Field("facility")
            .Type($"{nameof(GetAssetResponseFacility)}!")
            .Directive(new DelegateDirective("asset(id: $fields:facilityId)", "Assets"));
    }
}
