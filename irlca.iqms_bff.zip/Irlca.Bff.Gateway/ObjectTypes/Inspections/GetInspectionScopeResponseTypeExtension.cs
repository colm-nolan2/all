﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionScopeResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionScopeResponse));

        descriptor.Field("inspectionLetter")
            .Authorize(AuthorizationPolicies.ViewInspectionScopeLetter);

        descriptor
           .Field("assetIds")
           .Authorize(AuthorizationPolicies.ViewInspectionScopeAssets);

        descriptor
           .Field("assetGroupIds")
           .Authorize(AuthorizationPolicies.ViewInspectionScopeAssets);

        descriptor.Field("assets")
            .Type($"[{nameof(GetAssetResponse)}!]")
            .Authorize(AuthorizationPolicies.ViewInspectionScopeAssets)
            .Directive(new DelegateDirective("assets(ids: $fields:assetIds)", "Assets"));

        descriptor
            .Field("assetGroups")
            .Type($"[{nameof(GetAssetGroupResponse)}!]")
            .Authorize(AuthorizationPolicies.ViewInspectionScopeAssets)
            .Directive(new DelegateDirective("assetGroups(ids: $fields:assetGroupIds)", "Assets"));
    }
}
