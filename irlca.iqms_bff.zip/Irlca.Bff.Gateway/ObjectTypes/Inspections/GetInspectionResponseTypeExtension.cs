﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Authorize(AuthorizationPolicies.ViewInspections);

        descriptor.Name(nameof(GetInspectionResponse));

        descriptor
            .Field("preInspectionRequestIds")
            .Authorize(AuthorizationPolicies.ViewInspectionsPreInspectionRequests);

        descriptor
            .Field("requestIds")
            .Authorize(AuthorizationPolicies.ViewInspectionsRequest);

        descriptor
            .Field("preInspectionActionPlanId")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("inspectionActionPlanId")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("postInspectionActionPlanId")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("inspectionCloseOutActionPlanId")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("preInspectionTasks")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("inspectionTasks")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("postInspectionTasks")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("inspectionCloseOutTasks")
            .Authorize(AuthorizationPolicies.ViewInspectionsTasks);

        descriptor
            .Field("preInspectionRequests")
            .Type($"[{nameof(GetRequestResponse)}!]!")
            .Directive(new DelegateDirective("requests(ids: $fields:preInspectionRequestIds)", "Requests"));

        descriptor
            .Field("requests")
            .Type($"[{nameof(GetRequestResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionsRequest)
            .Directive(new DelegateDirective("requests(ids: $fields:requestIds)", "Requests"));

        descriptor
            .Field("inspectionChecklistExecutions")
            .Type($"[{nameof(GetChecklistExecutionResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionsInspectionChecklistExecutions)
            .Directive(new DelegateDirective("inspectionChecklistExecutions(inspectionId: $fields:id)", "Checklists"));

        descriptor
            .Field("preInspectionChecklistExecutions")
            .Type($"[{nameof(GetChecklistExecutionResponse)}!]!")
            .Authorize(AuthorizationPolicies.ViewInspectionsPreinspectionChecklistExecutions)
            .Directive(new DelegateDirective("preInspectionChecklistExecutions(inspectionId: $fields:id)", "Checklists"));

        descriptor
            .Field("reviews")
            .Authorize(AuthorizationPolicies.ViewInspectionsForReview);

        descriptor
           .Field("inspectorSuggestions")
           .Authorize(AuthorizationPolicies.ViewInspectionsInspectorSuggestion);
    }
}
