﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionSettingsAreaResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionSettingsAreaResponse));

        descriptor.Field("inspectionSettingsId").Ignore();

        descriptor
            .Field("createdBy")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:createdById)", "Iqms"));

        descriptor
            .Field("inspectionArea")
            .Type($"{nameof(GetInspectionAreaResponse)}")
            .Directive(new DelegateDirective("inspectionArea(id: $fields:inspectionAreaId)", "Iqms"));
    }
}
