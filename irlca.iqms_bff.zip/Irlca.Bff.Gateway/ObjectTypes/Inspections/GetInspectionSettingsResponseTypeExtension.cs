﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionSettingsResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionSettingsResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsSettings);

        descriptor.Field("inspectionAreaIds").Ignore();
        descriptor
            .Field("inspectionAreas")
            .Type($"[{nameof(GetInspectionSettingsAreaResponse)}!]")
            .Directive(new DelegateDirective("inspectionSettingsAreas", "Inspections"));
    }
}
