﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Issues;

public class GetDistributionListUsersResponseUserTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetDistributionListUsersResponseUser));

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsDistributionList);
    }
}
