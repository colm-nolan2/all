﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionObservationTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsObservation);

        descriptor.Name(nameof(GetObservationResponse));
    }
}
