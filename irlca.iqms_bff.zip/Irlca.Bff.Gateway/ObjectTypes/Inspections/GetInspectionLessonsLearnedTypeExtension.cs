﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionLessonsLearnedTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsLessonsLearned);

        descriptor.Name(nameof(GetLessonLearnedResponse));
    }
}
