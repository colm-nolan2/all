﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionEventResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Authorize(AuthorizationPolicies.ViewInspectionEvents);

        descriptor.Name(nameof(GetInspectionEventResponse));

        descriptor
            .Field("location")
            .Type($"{nameof(GetAssetResponse)}")
            .Directive(new DelegateDirective("asset(id: $fields:locationId)", "Assets"))
            .Deprecated("Please use asset(id) query to get the location. Since location is nullable it causes intermittent problem when resolving multiple locations when single location is not set");

        descriptor
            .Field("scribe")
            .Type("Scribe!")
            .Directive(new DelegateDirective("scribe(id: $fields:scribeId)", "Scribes"));
    }
}
