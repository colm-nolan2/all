﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Inspections;

public class GetInspectionTeamMemberResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionTeamMemberResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionPlanningTeam);
    }
}
