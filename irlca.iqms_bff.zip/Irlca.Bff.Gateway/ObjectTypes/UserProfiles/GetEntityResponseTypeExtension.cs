﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.UserProfiles;

public class GetEntityResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetEntityResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewEntities);
    }
}
