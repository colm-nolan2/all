﻿using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.UserProfiles;

public class GetDepartmentResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetDepartmentResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewDepartments);
    }
}
