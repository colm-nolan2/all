﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.InspectionReports;

public class GetInspectionReportResponseTopicTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionReportResponseTopic));

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("topic")
            .Type($"{nameof(GetAssetResponse)}!")
            .Directive(new DelegateDirective("asset(id: $fields:topicId)", "Assets"))
            .Authorize(AuthorizationPolicies.ViewAssets);
    }
}
