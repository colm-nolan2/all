﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.InspectionReports;

public class GetInspectionReportResponseItemIssueTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetInspectionReportResponseItemIssue");

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("issue")
            .Type($"{nameof(GetIssueResponse)}!")
            .Directive(new DelegateDirective("issue(id: $fields:itemId)", "Iqms"))
            .Authorize(AuthorizationPolicies.ViewIssues);
    }
}
