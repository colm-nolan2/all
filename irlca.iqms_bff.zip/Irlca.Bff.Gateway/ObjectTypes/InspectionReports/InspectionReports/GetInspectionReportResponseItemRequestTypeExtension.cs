﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.InspectionReports;

public class GetInspectionReportResponseItemRequestTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetInspectionReportResponseItemRequest");

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("request")
            .Type($"{nameof(GetRequestResponse)}!")
            .Directive(new DelegateDirective("request(id: $fields:itemId)", "Requests"))
            .Authorize(AuthorizationPolicies.ViewInspectionsRequest);
    }
}
