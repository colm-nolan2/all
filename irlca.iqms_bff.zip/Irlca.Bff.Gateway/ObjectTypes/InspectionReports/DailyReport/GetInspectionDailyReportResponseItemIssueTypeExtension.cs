﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.DailyReport;

public class GetInspectionDailyReportResponseItemIssueTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetInspectionDailyReportResponseItemIssue");

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("issue")
            .Type($"{nameof(GetIssueResponse)}!")
            .Directive(new DelegateDirective("issue(id: $fields:itemId)", "Iqms"))
            .Authorize(AuthorizationPolicies.ViewIssues);
    }
}
