﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.DailyReport;

public class GetInspectionDailyReportResponseItemInspectorSuggestionTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetInspectionDailyReportResponseItemInspectorSuggestion");

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("inspectorSuggestion")
            .Type($"{nameof(GetInspectorSuggestionResponse)}!")
            .Directive(new DelegateDirective("inspectorSuggestion(id: $fields:itemId)", "Iqms"))
            .Authorize(AuthorizationPolicies.ViewInspectionsInspectorSuggestion);
    }
}
