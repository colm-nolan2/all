﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.DailyReport;

public class GetInspectionDailyReportResponseItemReviewTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetInspectionDailyReportResponseItemReview");

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("review")
            .Type($"{nameof(GetReviewResponse)}!")
            .Directive(new DelegateDirective("review(id: $fields:itemId)", "Iqms"))
            .Authorize(AuthorizationPolicies.ViewInspectionsForReview);
    }
}
