﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.DailyReport;

public class GetInspectionDailyReportResponseItemRequestTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetInspectionDailyReportResponseItemRequest");

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("request")
            .Type($"{nameof(GetRequestResponse)}!")
            .Directive(new DelegateDirective("request(id: $fields:itemId)", "Requests"))
            .Authorize(AuthorizationPolicies.ViewInspectionsRequest);
    }
}
