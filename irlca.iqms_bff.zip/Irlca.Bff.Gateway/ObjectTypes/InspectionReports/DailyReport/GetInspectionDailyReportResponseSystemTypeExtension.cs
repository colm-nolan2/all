﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.InspectionReports.DailyReport;

public class GetInspectionDailyReportResponseSystemTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetInspectionDailyReportResponseSystem));

        descriptor.Authorize(AuthorizationPolicies.ViewInspectionsReport);

        descriptor
            .Field("system")
            .Type($"{nameof(GetAssetResponse)}!")
            .Directive(new DelegateDirective("asset(id: $fields:systemId)", "Assets"))
            .Authorize(AuthorizationPolicies.ViewAssets);
    }
}
