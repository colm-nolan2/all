﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Checklists;

public class GetChecklistDefinitionResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetChecklistDefinitionResponse));

        descriptor
            .Field("createdBy")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:createdById)", "Iqms"));
    }
}
