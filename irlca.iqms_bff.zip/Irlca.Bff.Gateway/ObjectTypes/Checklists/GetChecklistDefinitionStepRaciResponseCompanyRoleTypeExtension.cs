﻿using HotChocolate.Stitching;

namespace Irlca.Bff.Gateway.ObjectTypes.Checklists;

public class GetChecklistDefinitionStepRaciResponseCompanyRoleTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetChecklistDefinitionStepRaciResponseCompanyRole");

        descriptor
            .Field("name")
            .Type<StringType>()
            .Directive(
                new DelegateDirective("companyRole(entityId: $fields:entityId, departmentId: $fields:departmentId, roleId: $fields:roleId).name", "Iqms"));
    }
}
