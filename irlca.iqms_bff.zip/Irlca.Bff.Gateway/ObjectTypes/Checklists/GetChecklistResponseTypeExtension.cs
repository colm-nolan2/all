﻿using HotChocolate.Stitching;
using Irlca.Bff.Gateway.Authorization;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Checklists;

public class GetChecklistResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetChecklistResponse));

        descriptor.Authorize(AuthorizationPolicies.ViewChecklists);

        descriptor
            .Field("createdBy")
            .Type($"{nameof(GetUserProfileResponse)}!")
            .Directive(new DelegateDirective("user(id: $fields:createdById)", "Iqms"));
    }
}
