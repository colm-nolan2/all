﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Checklists;

public class GetChecklistStepExecutionResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetChecklistStepExecutionResponse));

        descriptor.Field("attachmentIds").Ignore();
        descriptor
            .Field("attachments")
            .Type($"[{nameof(GetDocumentDetailsResponse)}]!")
            .Directive(
                new DelegateDirective(
                    "checklistStepExecutionAttachments(checklistId: $fields:checklistId, definitionId: $fields:checklistDefinitionId, executionId: $fields:checklistExecutionId, stepId: $fields:id)",
                    "Iqms"));

        descriptor.Field("issueIds").Ignore();
        descriptor
            .Field("issues")
            .Type($"[{nameof(GetIssueResponse)}]!")
            .Directive(
                new DelegateDirective(
                    "checklistStepExecutionIssues(checklistId: $fields:checklistId, definitionId: $fields:checklistDefinitionId, executionId: $fields:checklistExecutionId, stepId: $fields:id)",
                    "Iqms"));
    }
}
