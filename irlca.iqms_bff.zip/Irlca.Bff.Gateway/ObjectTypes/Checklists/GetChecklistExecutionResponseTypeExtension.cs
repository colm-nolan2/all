﻿using HotChocolate.Stitching;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Gateway.ObjectTypes.Checklists;

public class GetChecklistExecutionResponseTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name(nameof(GetChecklistExecutionResponse));

        descriptor
            .Field("assignee")
            .Type(nameof(GetUserProfileResponse))
            .Directive(new DelegateDirective("user(id: $fields:assigneeId)", "Iqms"));

        descriptor
            .Field("participants")
            .Type($"[{nameof(GetUserProfileResponse)}]")
            .Directive(new DelegateDirective("users(ids: $fields:participantIds)", "Iqms"));
    }
}
