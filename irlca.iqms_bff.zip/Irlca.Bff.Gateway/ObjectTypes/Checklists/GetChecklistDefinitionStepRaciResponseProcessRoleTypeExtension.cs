﻿using HotChocolate.Stitching;

namespace Irlca.Bff.Gateway.ObjectTypes.Checklists;

public class GetChecklistDefinitionStepRaciResponseProcessRoleTypeExtension : ObjectTypeExtension
{
    protected override void Configure(IObjectTypeDescriptor descriptor)
    {
        descriptor.Name("GetChecklistDefinitionStepRaciResponseProcessRole");

        descriptor
            .Field("name")
            .Type<StringType>()
            .Directive(
                new DelegateDirective("processRole(entityId: $fields:entityId, departmentId: $fields:departmentId, roleId: $fields:roleId).name", "Iqms"));
    }
}
