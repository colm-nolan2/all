﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetInspectionLicenseResponse>> GetInspectionLicensesAsync(
        [Service] IIqmsClient client,
        [Service] InspectionLicensesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectionTypes = await client.GetInspectionLicensesAsync(cancellationToken);

        return await loader.LoadAsync([..inspectionTypes.InspectionLicenseIds], cancellationToken);
    }
}
