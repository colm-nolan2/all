﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetInspectionResponse>> GetInspectionsAsync(
        DateTimeOffset? from,
        DateTimeOffset? to,
        [Service] IIqmsClient client,
        InspectionDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectionIds = await client.GetInspectionsWithinPeriodAsync(
            from ?? DateTimeOffset.MinValue,
            to ?? DateTimeOffset.MaxValue,
            cancellationToken);

        return await loader.LoadAsync([..inspectionIds.InspectionIds], cancellationToken);
    }

    public async Task<GetInspectionResponse> GetInspectionAsync(
        Guid id,
        InspectionDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<GetInspectionSettingsResponse> GetInspectionSettings(IIqmsClient client, CancellationToken cancellationToken = default) =>
        await client.GetInspectionSettingsAsync(cancellationToken);
}
