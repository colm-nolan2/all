﻿using Irlca.Bff.Shared;
using Microsoft.AspNetCore.Http;

namespace Irlca.Bff.Iqms.Filters;

public class IqmsApiErrorFilter : IErrorFilter
{
    public IError OnError(IError error) =>
        error.Exception switch
        {
            ApiException<ProblemDetails> { StatusCode: StatusCodes.Status404NotFound } ex =>
                ErrorBuilder.New().SetMessage(ex.Result.Detail).SetCode("NOT_FOUND").Build(),
            ApiException { StatusCode: StatusCodes.Status404NotFound } ex =>
                ErrorBuilder.New().SetMessage(ex.Message).SetCode("NOT_FOUND").Build(),
            _ => error,
        };
}
