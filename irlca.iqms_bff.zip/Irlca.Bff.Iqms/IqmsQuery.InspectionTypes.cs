﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetInspectionTypeResponse>> GetInspectionTypesAsync(
        [Service] IIqmsClient client,
        [Service] InspectionTypesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectionTypes = await client.GetInspectionTypesAsync(cancellationToken);

        return await loader.LoadAsync([..inspectionTypes.InspectionTypeIds], cancellationToken);
    }
}
