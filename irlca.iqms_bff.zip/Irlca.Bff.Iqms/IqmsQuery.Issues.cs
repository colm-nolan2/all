﻿using Irlca.Bff.Iqms.DataLoaders.Issues;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<GetIssueResponse?> GetIssueAsync(Guid id, [Service] IssuesDataLoader loader, CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetIssueResponse?>> GetIssuesAsync(
        IReadOnlyList<Guid> ids,
        [Service] IssuesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);

    public async Task<IReadOnlyList<GetIssueResponse?>> GetAllIssuesAsync(
        [Service] IIqmsClient client,
        IssuesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var issues = await client.GetIssuesAsync(cancellationToken);

        return await loader.LoadAsync([..issues.Issues.Select(x => x.Id)], cancellationToken);
    }

    public async Task<GetIssueSettingsResponse> GetIssueSettingsAsync(
        IIqmsClient client,
        CancellationToken cancellationToken = default) =>
        await client.GetIssueSettingsAsync(cancellationToken);
}
