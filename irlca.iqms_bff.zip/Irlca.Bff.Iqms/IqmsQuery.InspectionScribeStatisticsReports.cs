﻿using Irlca.Bff.Iqms.DataLoaders.InspectionScribeStatisticsReport;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<GetInspectionScribeStatisticsReportResponse> GetInspectionScribeStatisticsReportAsync(
        Guid inspectionId,
        Guid scribeId,
        InspectionScribeStatisticsReportDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((inspectionId, scribeId), cancellationToken);
}
