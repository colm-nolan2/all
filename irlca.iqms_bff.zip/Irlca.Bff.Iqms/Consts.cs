﻿namespace Irlca.Bff.Iqms;

public static class Consts
{
    public const string SchemaName = "Iqms";
}
