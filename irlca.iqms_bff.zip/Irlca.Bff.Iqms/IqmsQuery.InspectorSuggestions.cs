﻿using Irlca.Bff.Iqms.DataLoaders.InspectorSuggestions;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<GetInspectorSuggestionResponse?> GetInspectorSuggestionAsync(
        Guid id,
        InspectorSuggestionsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
