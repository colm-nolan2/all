﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.TenantsManagement;

public class GetRoleResponseTypeExtension : ObjectTypeExtension<GetRoleResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetRoleResponse> descriptor)
    {
        descriptor.Ignore(x => x.PermissionIds);

        descriptor
            .Field("permissions")
            .Type<NonNullType<IType>>()
            .Resolve(async (ctx, ct) =>
            {
                var parent = ctx.Parent<GetRoleResponse>();
                var loader = ctx.Service<PermissionsDataLoader>();

                var result = await loader.LoadAsync(parent.PermissionIds.ToList(), ct);

                return result.Where(x => x is not null);
            });
    }
}
