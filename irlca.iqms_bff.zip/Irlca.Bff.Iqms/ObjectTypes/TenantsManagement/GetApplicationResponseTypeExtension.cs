﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.TenantsManagement;

public class GetApplicationResponseTypeExtnsion : ObjectTypeExtension<GetApplicationResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetApplicationResponse> descriptor)
    {
        descriptor.Ignore(x => x.PermissionIds);

        descriptor
            .Field("permissions")
            .Resolve(async (ctx, ct) =>
            {
                var parent = ctx.Parent<GetApplicationResponse>();
                var loader = ctx.Service<PermissionsDataLoader>();

                return await loader.LoadAsync(parent.PermissionIds.ToList(), ct);
            });
    }
}
