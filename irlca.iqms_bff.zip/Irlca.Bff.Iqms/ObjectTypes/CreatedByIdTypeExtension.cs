﻿using Irlca.Bff.Iqms.Resolvers;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes;

public class CreatedByIdTypeExtension : ObjectTypeExtension<ICreatedById>
{
    protected override void Configure(IObjectTypeDescriptor<ICreatedById> descriptor)
    {
        descriptor.ExtendsType<ICreatedById>();

        descriptor.Ignore(x => x.CreatedById);

        descriptor
            .Field("createdBy")
            .ResolveWith<CreatedByIdResolver>(x => x.ResolveCreatedBy(default!, default!, default));
    }
}
