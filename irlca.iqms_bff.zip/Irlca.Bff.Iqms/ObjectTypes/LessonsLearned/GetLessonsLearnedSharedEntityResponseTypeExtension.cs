﻿using Irlca.Bff.Iqms.Resolvers.LessonsLearned;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.LessonsLearned;

public class GetLessonsLearnedSharedEntityResponseTypeExtension : ObjectTypeExtension<GetLessonsLearnedSharedEntityResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetLessonsLearnedSharedEntityResponse> descriptor)
    {
        descriptor.Ignore(x => x.EntityId);

        descriptor
            .Field("entity")
            .ResolveWith<GetLessonsLearnedSharedEntityResolvers>(x => x.ResolveEntity(default!, default!, default));
    }
}
