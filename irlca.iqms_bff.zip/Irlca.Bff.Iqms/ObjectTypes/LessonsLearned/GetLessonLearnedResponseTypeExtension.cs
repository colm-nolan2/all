﻿using Irlca.Bff.Iqms.Resolvers.LessonsLearned;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.LessonsLearned;

public class GetLessonLearnedResponseTypeExtension : ObjectTypeExtension<GetLessonLearnedResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetLessonLearnedResponse> descriptor)
    {
        descriptor.Ignore(x => x.TenantId);

        descriptor.Ignore(x => x.RaisedById);
        descriptor
            .Field("raisedBy")
            .ResolveWith<GetLessonLearnedResponseResolvers>(x => x.ResolveRaisedBy(default!, default!, default));

        descriptor
            .Field("sharedEntities")
            .ResolveWith<GetLessonLearnedResponseResolvers>(x => x.ResolveSharedEntity(default!, default!, default));
    }
}
