﻿using Irlca.Bff.Iqms.Resolvers.Issues;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Issues;

public class GetIssueResponseTypeExtension : ObjectTypeExtension<GetIssueResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetIssueResponse> descriptor)
    {
        descriptor.Ignore(x => x.RaisedById);
        descriptor
            .Field("raisedBy")
            .ResolveWith<GetIssueResponseResolvers>(x => x.ResolveRaisedBy(default!, default!, default));

        descriptor.Ignore(x => x.IssueAssessments);
        descriptor
            .Field("assessments")
            .Resolve(ctx => ctx.Parent<GetIssueResponse>().IssueAssessments);

        descriptor.Ignore(x => x.LatestIssueAssessmentId);
        descriptor
            .Field("latestIssueAssessment")
            .ResolveWith<GetIssueResponseResolvers>(x => x.ResolveLatestIssueAssessment(default!, default!, default));
    }
}
