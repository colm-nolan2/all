﻿using Irlca.Bff.Iqms.Resolvers.Issues;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Issues;

public class GetIssueAssessmentResponseTypeExtension : ObjectTypeExtension<GetIssueAssessmentResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetIssueAssessmentResponse> descriptor)
    {
        descriptor.Ignore(x => x.IssueId);

        descriptor.Ignore(x => x.ClassificationById);
        descriptor
            .Field("classifiedBy")
            .ResolveWith<GetIssueAssessmentResponseResolvers>(x => x.ResolveClassifiedBy(default!, default!, default));

        descriptor.Ignore(x => x.CoordinatorId);
        descriptor
            .Field("coordinator")
            .ResolveWith<GetIssueAssessmentResponseResolvers>(x => x.ResolveCoordinator(default!, default!, default));

        descriptor.Ignore(x => x.ReviewerId);
        descriptor
            .Field("reviewer")
            .ResolveWith<GetIssueAssessmentResponseResolvers>(x => x.ResolveReviewer(default!, default!, default));

        descriptor.Ignore(x => x.AttachmentIds);
        descriptor
            .Field("attachments")
            .ResolveWith<GetIssueAssessmentResponseResolvers>(x => x.ResolveAttachments(default!, default!, default));

        descriptor.Ignore(x => x.CommentIds);
        descriptor
            .Field("comments")
            .ResolveWith<GetIssueAssessmentResponseResolvers>(x => x.ResolveComments(default!, default!, default));

        descriptor.Ignore(x => x.ActionPlanId);
        descriptor
            .Field("tasks")
            .ResolveWith<GetIssueAssessmentResponseResolvers>(x => x.ResolveTasks(default!, default!, default));
    }
}
