﻿using Irlca.Bff.Iqms.Resolvers.Issues;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Issues;

public class GetIssueResponseIssueAssessmentTypeExtension : ObjectTypeExtension<GetIssueResponseIssueAssessment>
{
    protected override void Configure(IObjectTypeDescriptor<GetIssueResponseIssueAssessment> descriptor)
    {
        descriptor.Ignore(x => x.IssueId);

        descriptor.Ignore(x => x.ClassificationById);
        descriptor
            .Field("classifiedBy")
            .ResolveWith<GetIssueResponseIssueAssessmentResolvers>(x => x.ResolveClassifiedBy(default!, default!, default));

        descriptor.Ignore(x => x.CoordinatorId);
        descriptor
            .Field("coordinator")
            .ResolveWith<GetIssueResponseIssueAssessmentResolvers>(x => x.ResolveCoordinator(default!, default!, default));

        descriptor.Ignore(x => x.ReviewerId);
        descriptor
            .Field("reviewer")
            .ResolveWith<GetIssueResponseIssueAssessmentResolvers>(x => x.ResolveReviewer(default!, default!, default));

        descriptor.Ignore(x => x.AttachmentIds);
        descriptor
            .Field("attachments")
            .ResolveWith<GetIssueResponseIssueAssessmentResolvers>(x => x.ResolveAttachments(default!, default!, default));

        descriptor.Ignore(x => x.CommentIds);
        descriptor
            .Field("comments")
            .ResolveWith<GetIssueResponseIssueAssessmentResolvers>(x => x.ResolveComments(default!, default!, default));

        descriptor.Ignore(x => x.ActionPlanId);
        descriptor
            .Field("tasks")
            .ResolveWith<GetIssueResponseIssueAssessmentResolvers>(x => x.ResolveTasks(default!, default!, default));
    }
}
