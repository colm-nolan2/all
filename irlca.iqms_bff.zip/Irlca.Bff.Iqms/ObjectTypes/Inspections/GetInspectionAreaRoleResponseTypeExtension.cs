﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionAreaRoleResponseTypeExtension : ObjectTypeExtension<GetInspectionAreaRoleResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionAreaRoleResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionAreaId);
    }
}
