﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionTeamMemberResponseObjectTypeExtension : ObjectTypeExtension<GetInspectionTeamMemberResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionTeamMemberResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionId);

        descriptor.Ignore(x => x.UserId);
        descriptor
            .Field("user")
            .ResolveWith<GetInspectionTeamMemberResponseResolvers>(x => x.ResolveUser(default!, default!, default));

        descriptor.Ignore(x => x.RoleId);
        descriptor
            .Field("role")
            .ResolveWith<GetInspectionTeamMemberResponseResolvers>(x => x.ResolveRole(default!, default!, default));
    }
}
