﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectorReportResponseInspectorDocumentTypeExtension : ObjectTypeExtension<GetInspectorReportResponseInspectorDocument>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectorReportResponseInspectorDocument> descriptor)
    {
        descriptor
            .Field("uploadedBy")
            .ResolveWith<GetInspectorReportResponseInspectorDocumentResolvers>(x => x.ResolveUploadedBy(default!, default!, default));

        descriptor.Ignore(x => x.InspectorId);
        descriptor
            .Field("inspector")
            .ResolveWith<GetInspectorReportResponseInspectorDocumentResolvers>(x => x.ResolveInspector(default!, default!, default));

        descriptor.Ignore(x => x.DocumentId);
        descriptor
            .Field("document")
            .ResolveWith<GetInspectorReportResponseInspectorDocumentResolvers>(x => x.ResolveDocument(default!, default!, default));
    }
}
