﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionSettingsResponseTypeExtension : ObjectTypeExtension<GetInspectionSettingsResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionSettingsResponse> descriptor)
    {
        descriptor
            .Field("inspectionAgencies")
            .ResolveWith<GetInspectionSettingsResponseResolvers>(x => x.ResolveInspectionAgencies(default!, default!, default));
    }
}
