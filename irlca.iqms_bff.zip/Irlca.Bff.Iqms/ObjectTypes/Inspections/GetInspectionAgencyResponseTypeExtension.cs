﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionAgencyResponseTypeExtension : ObjectTypeExtension<GetInspectionAgencyProfileResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionAgencyProfileResponse> descriptor)
    {
        descriptor
            .Field("inspectors")
            .ResolveWith<GetInspectionAgencyProfileResponseResolvers>(x => x.ResolveInspectors(default!, default!, default!, default));
    }
}
