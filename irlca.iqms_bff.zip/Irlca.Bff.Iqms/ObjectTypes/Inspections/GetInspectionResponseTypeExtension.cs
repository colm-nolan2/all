﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionResponseTypeExtension : ObjectTypeExtension<GetInspectionResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionLeadId);
        descriptor
            .Field("inspectionLead")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionLead(default!, default!, default));

        descriptor
            .Field("inspectionAreaSnapshot")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionAreaSnapshot(default!, default!, default));

        descriptor.Ignore(x => x.InspectionAgencyId);
        descriptor
            .Field("inspectionAgency")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionAgency(default!, default!, default));

        descriptor.Ignore(x => x.InspectionTypeId);
        descriptor
            .Field("inspectionType")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionType(default!, default!, default));

        descriptor.Ignore(x => x.InspectedEntityId);
        descriptor
            .Field("inspectedEntity")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectedEntity(default!, default!, default));

        descriptor.Ignore(x => x.InspectionLicenceId);
        descriptor
            .Field("inspectionLicense")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionLicense(default!, default!, default));

        descriptor
            .Field("scope")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveScope(default!, default!, default));

        descriptor
            .Field("events")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveEvents(default!, default!, default));

        descriptor
            .Field("event")
            .Argument("id", d => d.Type<UuidType>())
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveEvent(default, default!, default!, default));

        descriptor.Ignore(x => x.InspectorIds);
        descriptor
            .Field("inspectors")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectors(default!, default!, default));

        descriptor
            .Field("issues")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveIssues(default!, default!, default!, default));

        descriptor
            .Field("distributionList")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveDistributionList(default!, default!, default));

        descriptor
            .Field("observations")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveObservations(default!, default!, default!, default));

        descriptor
            .Field("requestIds")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveRequestIds(default!, default!, default));

        descriptor
            .Field("preInspectionRequestIds")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolvePreInspectionRequestIds(default!, default!, default));

        descriptor
            .Field("reviews")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveReviews(default!, default!, default!, default));

        descriptor
            .Field("inspectorSuggestions")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectorSuggestions(default!, default!, default!, default));

        descriptor
            .Field("lessonsLearned")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveLessonsLearned(default!, default!, default!, default));

        descriptor
            .Field("team")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveTeamMembers(default!, default!, default));

        descriptor
            .Field("preInspectionTasks")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolvePreInspectionTasks(default!, default!, default));

        descriptor
            .Field("inspectionTasks")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionTasks(default!, default!, default));

        descriptor
            .Field("postInspectionTasks")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolvePostInspectionTasks(default!, default!, default));

        descriptor
            .Field("inspectionCloseOutTasks")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectionCloseOutTasks(default!, default!, default));

        descriptor
            .Field("inspectorReport")
            .ResolveWith<GetInspectionResponseResolvers>(x => x.ResolveInspectorReport(default!, default!, default));
    }
}
