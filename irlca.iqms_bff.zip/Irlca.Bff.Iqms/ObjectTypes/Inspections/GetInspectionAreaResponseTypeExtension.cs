﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionAreaResponseTypeExtension : ObjectTypeExtension<GetInspectionAreaResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionAreaResponse> descriptor)
    {
        descriptor
            .Field("roles")
            .ResolveWith<GetInspectionAreaResponseResolvers>(x => x.ResolveRoles(default!, default!, default));
    }
}
