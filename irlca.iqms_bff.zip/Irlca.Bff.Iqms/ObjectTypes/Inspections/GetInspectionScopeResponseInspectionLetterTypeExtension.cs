﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionScopeResponseInspectionLetterTypeExtension : ObjectTypeExtension<GetInspectionScopeResponseInspectionLetter>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionScopeResponseInspectionLetter> descriptor)
    {
        descriptor
            .Field("uploadedBy")
            .ResolveWith<GetInspectionScopeResponseInspectionLetterResolvers>(x => x.ResolveUploadedBy(default!, default!, default));

        descriptor.Ignore(x => x.DocumentId);
        descriptor
            .Field("document")
            .ResolveWith<GetInspectionScopeResponseInspectionLetterResolvers>(x => x.ResolveDocument(default!, default!, default));
    }
}
