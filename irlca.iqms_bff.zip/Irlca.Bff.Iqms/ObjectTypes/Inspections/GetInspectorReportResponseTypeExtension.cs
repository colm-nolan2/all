﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectorReportResponseTypeExtension : ObjectTypeExtension<GetInspectorReportResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectorReportResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionId);
    }
}
