﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionAreaSnapshotResponseTypeExtension : ObjectTypeExtension<GetInspectionAreaSnapshotResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionAreaSnapshotResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionId);

        descriptor.Ignore(x => x.RoleIds);
        descriptor
            .Field("roles")
            .ResolveWith<GetInspectionAreaSnapshotResponseResolvers>(x => x.ResolveRoles(default!, default!, default));
    }
}
