﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetDistributionListUsersResponseUserTypeExtension : ObjectTypeExtension<GetDistributionListUsersResponseUser>
{
    protected override void Configure(IObjectTypeDescriptor<GetDistributionListUsersResponseUser> descriptor)
    {
        descriptor.Ignore(x => x.UserId);
        descriptor
            .Field("user")
            .ResolveWith<GetDistributionListUsersResponseUserResolvers>(x => x.ResolveUser(default!, default!, default));
    }
}
