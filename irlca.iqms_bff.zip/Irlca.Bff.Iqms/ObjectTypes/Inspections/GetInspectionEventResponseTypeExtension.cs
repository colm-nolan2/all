﻿using Irlca.Bff.Iqms.Resolvers.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Inspections;

public class GetInspectionEventResponseTypeExtension : ObjectTypeExtension<GetInspectionEventResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionEventResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionId);

        descriptor.Ignore(x => x.AttachmentId);
        descriptor
            .Field("attachment")
            .ResolveWith<GetInspectionEventResponseResolvers>(x => x.ResolveAttachment(default!, default!, default));

        descriptor.Ignore(x => x.AttendeeIds);
        descriptor
            .Field("attendees")
            .ResolveWith<GetInspectionEventResponseResolvers>(x => x.ResolveAttendees(default!, default!, default));
    }
}
