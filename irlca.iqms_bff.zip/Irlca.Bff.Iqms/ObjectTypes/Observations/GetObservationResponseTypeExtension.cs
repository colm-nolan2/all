﻿using Irlca.Bff.Iqms.Resolvers.Observations;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Observations;

public class GetObservationResponseTypeExtension : ObjectTypeExtension<GetObservationResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetObservationResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectorId);
        descriptor
            .Field("inspector")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveInspector(default!, default!, default));

        descriptor.Ignore(x => x.CoordinatorId);
        descriptor
            .Field("coordinator")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveCoordinator(default!, default!, default));

        descriptor.Ignore(x => x.ReviewerId);
        descriptor
            .Field("reviewer")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveReviewer(default!, default!, default));

        descriptor.Ignore(x => x.RaisedById);
        descriptor
            .Field("raisedBy")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveRaisedBy(default!, default!, default));

        descriptor.Ignore(x => x.AttachmentIds);
        descriptor
            .Field("attachments")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveAttachments(default!, default!, default));

        descriptor.Ignore(x => x.CommentIds);
        descriptor
            .Field("comments")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveComments(default!, default!, default));

        descriptor.Ignore(x => x.ActionPlanId);
        descriptor
            .Field("tasks")
            .ResolveWith<GetObservationResponseResolvers>(x => x.ResolveTasks(default!, default!, default));
    }
}
