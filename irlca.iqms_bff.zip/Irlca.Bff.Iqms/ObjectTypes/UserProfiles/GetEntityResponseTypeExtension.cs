﻿using Irlca.Bff.Iqms.Resolvers.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.UserProfiles;

public class GetEntityResponseTypeExtension : ObjectTypeExtension<GetEntityResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetEntityResponse> descriptor)
    {
        descriptor
            .Field("departments")
            .ResolveWith<GetEntityResponseResolvers>(x => x.ResolveDepartments(default!, default!, default!, default));
    }
}
