﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.UserProfiles;

public class GetTenantProfileResponseTypeExtension : ObjectTypeExtension<GetTenantProfileResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetTenantProfileResponse> descriptor)
    {
        descriptor.Ignore(x => x.TenantId);
    }
}
