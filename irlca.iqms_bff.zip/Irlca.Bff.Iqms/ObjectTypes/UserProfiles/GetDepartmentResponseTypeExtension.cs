﻿using Irlca.Bff.Iqms.Resolvers.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.UserProfiles;

public class GetDepartmentResponseTypeExtension : ObjectTypeExtension<GetDepartmentResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetDepartmentResponse> descriptor)
    {
        descriptor
            .Field("companyRoles")
            .ResolveWith<GetDepartmentResponseResolvers>(x => x.ResolveCompanyRoles(default!, default!, default));

        descriptor
            .Field("processRoles")
            .ResolveWith<GetDepartmentResponseResolvers>(x => x.ResolveProcessRoles(default!, default!, default));
    }
}
