﻿using Irlca.Bff.Iqms.Resolvers.Comments;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Comments;

public class GetChildCommentResponseTypeExtension : ObjectTypeExtension<GetChildCommentResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetChildCommentResponse> descriptor)
    {
        descriptor.Ignore(x => x.ChildCommentIds);

        descriptor.Ignore(x => x.AuthorId);
        descriptor
            .Field("author")
            .ResolveWith<GetCommentResponseResolvers>(x => x.ResolveAuthor(default!, default!, default));
    }
}
