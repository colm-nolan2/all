﻿using Irlca.Bff.Iqms.Resolvers.Comments;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Comments;

public class GetCommentResponseTypeExtension : ObjectTypeExtension<GetCommentResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetCommentResponse> descriptor)
    {
        descriptor.Ignore(x => x.AuthorId);
        descriptor
            .Field("author")
            .ResolveWith<GetCommentResponseResolvers>(x => x.ResolveAuthor(default!, default!, default));

        descriptor.Ignore(x => x.ChildCommentIds);
        descriptor
            .Field("childComments")
            .ResolveWith<GetCommentResponseResolvers>(x => x.ResolveChildComments(default!, default!, default));
    }
}
