﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.InspectionScribeReport;

public class GetInspectionScribeStatisticsReportResponseObjectTypeExtension : ObjectTypeExtension<GetInspectionScribeStatisticsReportResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectionScribeStatisticsReportResponse> descriptor)
    {
        descriptor.Ignore(x => x.InspectionId);
        descriptor.Ignore(x => x.ScribeId);
    }
}
