﻿using Irlca.Bff.Iqms.Resolvers.InspectorSuggestions;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.InspectorSuggestions;

public class GetInspectorSuggestionResponseInspectorObjectTypeExtension : ObjectTypeExtension<GetInspectorSuggestionResponseInspector>
{
    protected override void Configure(IObjectTypeDescriptor<GetInspectorSuggestionResponseInspector> descriptor)
    {
        descriptor.Ignore(x => x.InspectorId);
        descriptor
            .Field("inspector")
            .ResolveWith<GetInspectorSuggestionResponseInspectorResolvers>(x => x.ResolveInspector(default!, default!, default));

        descriptor.Ignore(x => x.InspectionAgencyId);
        descriptor
            .Field("inspectionAgency")
            .ResolveWith<GetInspectorSuggestionResponseInspectorResolvers>(x => x.ResolveInspectionAgency(default!, default!, default));
    }
}
