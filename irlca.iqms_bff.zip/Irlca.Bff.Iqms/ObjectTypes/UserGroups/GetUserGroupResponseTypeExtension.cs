﻿using Irlca.Bff.Iqms.Resolvers.UserGroups;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.UserGroups;

public class GetUserGroupResponseTypeExtension : ObjectTypeExtension<GetUserGroupResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetUserGroupResponse> descriptor)
    {
        descriptor
            .Field(x => x.Users)
            .ResolveWith<GetUserGroupResponseResolvers>(x => x.ResolveUsers(default!, default!, default));
    }
}
