﻿using Irlca.Bff.Iqms.Resolvers.Tasks;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Tasks;

public class GetActionPlanResponseTypeExtensions : ObjectTypeExtension<GetActionPlanResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetActionPlanResponse> descriptor)
    {
        descriptor
            .Field("tasks")
            .ResolveWith<GetActionPlanResponseResolvers>(x => x.ResolveTasks(default!, default!, default));
    }
}
