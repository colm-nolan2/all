﻿using Irlca.Bff.Iqms.Resolvers.Tasks;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Tasks;

public class GetTaskResponseTypeExtension : ObjectTypeExtension<GetTaskResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetTaskResponse> descriptor)
    {
        descriptor.Ignore(x => x.AssignedToId);
        descriptor
            .Field("assignedTo")
            .ResolveWith<GetTaskResponseResolvers>(x => x.ResolveAssignedTo(default!, default!, default));

        descriptor.Ignore(x => x.CommentIds);
        descriptor
            .Field("comments")
            .ResolveWith<GetTaskResponseResolvers>(x => x.ResolveComments(default!, default!, default));

        descriptor.Ignore(x => x.AttachmentIds);
        descriptor
            .Field("attachments")
            .ResolveWith<GetTaskResponseResolvers>(x => x.ResolveAttachments(default!, default!, default));
    }
}
