﻿using Irlca.Bff.Iqms.Resolvers.Reviews;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.ObjectTypes.Reviews;

public class GetReviewResponseTypeExtension : ObjectTypeExtension<GetReviewResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetReviewResponse> descriptor)
    {
        descriptor.Ignore(x => x.OwnerId);
        descriptor
            .Field("owner")
            .ResolveWith<GetReviewResponseResolvers>(x => x.ResolveOwner(default!, default!, default));

        descriptor.Ignore(x => x.RaisedById);
        descriptor
            .Field("raisedBy")
            .ResolveWith<GetReviewResponseResolvers>(x => x.ResolveRaisedBy(default!, default!, default));
    }
}
