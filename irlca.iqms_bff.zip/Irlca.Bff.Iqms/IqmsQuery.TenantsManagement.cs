﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetApplicationResponse>> GetApplicationsAsync(
        [Service] IIqmsClient client,
        ApplicationsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var tenantApplications = await client.GetTenantApplicationsAsync(cancellationToken);

        return await loader.LoadAsync([..tenantApplications.ApplicationIds], cancellationToken);
    }

    public async Task<GetApplicationResponse?> GetApplicationAsync(Guid id, ApplicationsDataLoader loader, CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetPermissionResponse?>> GetPermissionsAsync(
        IReadOnlyList<Guid> ids,
        PermissionsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);

    public async Task<GetPermissionResponse?> GetPermissionAsync(
        Guid id,
        PermissionsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetRoleResponse>> GetRolesAsync(
        [Service] IIqmsClient client,
        RolesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var roles = await client.GetRolesAsync(cancellationToken);

        return await loader.LoadAsync([..roles.RoleIds], cancellationToken);
    }

    public async Task<GetRoleResponse?> GetRoleAsync(
        Guid id,
        RolesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
