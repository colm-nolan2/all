﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetInspectionAreaResponse>> GetInspectionAreasAsync(
        IIqmsClient client,
        InspectionAreasDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectionAreas = await client.GetInspectionAreasAsync(cancellationToken);

        return await loader.LoadAsync([..inspectionAreas.InspectionAreaIds], cancellationToken);
    }

    public async Task<GetInspectionAreaResponse?> GetInspectionAreaAsync(
        Guid id,
        InspectionAreasDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<GetInspectionAreaRoleResponse> GetInspectionAreaRoleAsync(
        Guid areaId,
        Guid roleId,
        InspectionAreaRolesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((areaId, roleId), cancellationToken);
}
