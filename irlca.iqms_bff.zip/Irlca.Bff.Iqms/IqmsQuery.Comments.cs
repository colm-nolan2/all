﻿using Irlca.Bff.Iqms.DataLoaders.Comments;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetCommentResponse>> GetCommentsAsync(
        IReadOnlyList<Guid> ids,
        [Service] CommentsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);

    public async Task<GetCommentResponse> GetCommentAsync(Guid id, [Service] CommentsDataLoader loader, CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
