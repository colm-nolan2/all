﻿using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<GetDocumentDetailsResponse> GetDocumentAsync(
        Guid id,
        [Service] DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetDocumentDetailsResponse>> GetDocumentsAsync(
        IReadOnlyList<Guid> ids,
        [Service] DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);
}
