﻿using Irlca.Bff.Iqms.DataLoaders.UserGroups;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetUserGroupResponse>> GetUserGroupsAsync(
        [Service] IIqmsClient client,
        UserGroupsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var userGroupIds = await client.GetUserGroupsAsync(cancellationToken);

        var ids = userGroupIds.UserGroups
            .Select(x => x.Id);

        return await loader.LoadAsync([..ids], cancellationToken);
    }

    public async Task<GetUserGroupResponse> GetUserGroupAsync(Guid id, UserGroupsDataLoader loader, CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
