﻿using Irlca.Bff.Iqms.DataLoaders.Tasks;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetTaskResponse>> GetTasksAsync(
        [Service] IIqmsClient client,
        TasksDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var taskIds = await client.GetTasksAsync(cancellationToken);

        return await loader.LoadAsync([..taskIds.TaskIds], cancellationToken);
    }

    public async Task<GetTaskResponse?> GetTaskAsync(
        Guid id,
        TasksDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<GetTaskSettingsResponse> GetTaskSettingsAsync(
        IIqmsClient client,
        CancellationToken cancellationToken = default) =>
        await client.GetTaskSettingsAsync(cancellationToken);
}
