﻿using Irlca.Bff.Iqms.DataLoaders.Tasks;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<GetActionPlanResponse?> GetActionPlanAsync(
        Guid id,
        ActionPlansDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
