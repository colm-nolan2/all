﻿using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.Issues;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetDocumentDetailsResponse?>> GetChecklistStepExecutionAttachmentsAsync(
        Guid checklistId,
        Guid definitionId,
        Guid executionId,
        Guid stepId,
        [Service] IIqmsClient client,
        [Service] DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var step = await client.GetChecklistStepExecutionAsync(checklistId, definitionId, executionId, stepId, cancellationToken);

        return await loader.LoadAsync([..step.AttachmentIds], cancellationToken);
    }

    public async Task<IReadOnlyList<GetIssueResponse?>> GetChecklistStepExecutionIssuesAsync(
        Guid checklistId,
        Guid definitionId,
        Guid executionId,
        Guid stepId,
        [Service] IIqmsClient client,
        [Service] IssuesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var step = await client.GetChecklistStepExecutionAsync(checklistId, definitionId, executionId, stepId, cancellationToken);

        var result = await loader.LoadAsync([..step.IssueIds], cancellationToken);

        return result;
    }

    public async Task<IReadOnlyList<GetIssueResponse?>> GetAllChecklistExecutionIssuesAsync(
        [Service] IIqmsClient client,
        IssuesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var issueIds = await client.GetChecklistExecutionIssuesAsync(cancellationToken);

        return await loader.LoadAsync([..issueIds.IssueIds], cancellationToken);
    }

    public async Task<GetChecklistSettingsResponse> GetChecklistSettingsAsync(
        IIqmsClient client,
        CancellationToken cancellationToken = default) =>
        await client.GetChecklistSettingsAsync(cancellationToken);
}
