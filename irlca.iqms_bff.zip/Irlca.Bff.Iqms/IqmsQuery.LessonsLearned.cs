﻿using Irlca.Bff.Iqms.DataLoaders.LessonsLearned;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyCollection<GetLessonLearnedResponse>> GetAllLessonsLearnedAsync(
        IIqmsClient client,
        LessonsLearnedDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var lessonsLearned = await client.GetLessonsLearnedAsync(cancellationToken);

        return await loader.LoadAsync([..lessonsLearned.LessonsLearnedIds], cancellationToken);
    }

    public async Task<GetLessonLearnedResponse> GetLessonLearnedAsync(
        Guid id,
        LessonsLearnedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
