﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers;

public class CreatedByIdResolver
{
    public async Task<GetUserProfileResponse> ResolveCreatedBy(
        [Parent] ICreatedById parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.CreatedById, cancellationToken);
}
