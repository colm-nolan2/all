﻿using Irlca.Bff.Iqms.DataLoaders.Tasks;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Tasks;

public class GetActionPlanResponseResolvers
{
    public async Task<IReadOnlyList<GetTaskResponse>> ResolveTasks(
        [Parent] GetActionPlanResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);
}
