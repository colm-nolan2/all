﻿using Irlca.Bff.Iqms.DataLoaders.Comments;
using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Tasks;

public class GetTaskResponseResolvers
{
    public async Task<IReadOnlyList<GetCommentResponse>> ResolveComments(
        [Parent] GetTaskResponse parent,
        [Service] CommentsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.CommentIds], cancellationToken);

    public async Task<GetUserProfileResponse> ResolveAssignedTo(
        [Parent] GetTaskResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.AssignedToId, cancellationToken);

    public async Task<IReadOnlyList<GetDocumentDetailsResponse>> ResolveAttachments(
        [Parent] GetTaskResponse parent,
        DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.AttachmentIds], cancellationToken);
}
