﻿using Irlca.Bff.Iqms.DataLoaders.Comments;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Comments;

public class GetCommentResponseResolvers
{
    public async Task<GetUserProfileResponse> ResolveAuthor(
        [Parent] GetCommentResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.AuthorId, cancellationToken);

    public async Task<IReadOnlyList<GetChildCommentResponse>> ResolveChildComments(
        [Parent] GetCommentResponse parent,
        ChildCommentsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.ChildCommentIds], cancellationToken);
}
