﻿using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionScopeResponseInspectionLetterResolvers
{
    public async Task<GetUserProfileResponse?> ResolveUploadedBy(
        [Parent] GetInspectionScopeResponseInspectionLetter parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.UploadedBy.HasValue ? await loader.LoadAsync(parent.UploadedBy.Value, cancellationToken) : null;

    public async Task<GetDocumentDetailsResponse?> ResolveDocument(
        [Parent] GetInspectionScopeResponseInspectionLetter parent,
        DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.DocumentId.HasValue ? await loader.LoadAsync(parent.DocumentId.Value, cancellationToken) : null;
}
