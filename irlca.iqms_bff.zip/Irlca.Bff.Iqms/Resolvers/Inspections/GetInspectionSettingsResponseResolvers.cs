﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionSettingsResponseResolvers
{
    public async Task<IReadOnlyList<GetInspectionAgencyProfileResponse>> ResolveInspectionAgencies(
        [Service] IIqmsClient client,
        [Service] InspectionAgencyProfilesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectionAgencies = await client.GetInspectionSettingsInspectionAgenciesAsync(cancellationToken);

        return await loader.LoadAsync([..inspectionAgencies.InspectionAgencyIds], cancellationToken);
    }
}
