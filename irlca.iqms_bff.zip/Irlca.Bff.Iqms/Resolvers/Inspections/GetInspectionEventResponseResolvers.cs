﻿using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionEventResponseResolvers
{
    public async Task<GetDocumentDetailsResponse?> ResolveAttachment(
        [Parent] GetInspectionEventResponse parent,
        [Service] DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.AttachmentId.HasValue ? await loader.LoadAsync(parent.AttachmentId.Value, cancellationToken) : null;

    public async Task<IReadOnlyList<GetUserProfileResponse>> ResolveAttendees(
        [Parent] GetInspectionEventResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.AttendeeIds], cancellationToken);
}
