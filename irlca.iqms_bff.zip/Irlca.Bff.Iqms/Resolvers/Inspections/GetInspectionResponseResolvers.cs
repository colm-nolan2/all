﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Iqms.DataLoaders.InspectorSuggestions;
using Irlca.Bff.Iqms.DataLoaders.Issues;
using Irlca.Bff.Iqms.DataLoaders.LessonsLearned;
using Irlca.Bff.Iqms.DataLoaders.Observations;
using Irlca.Bff.Iqms.DataLoaders.Reviews;
using Irlca.Bff.Iqms.DataLoaders.Tasks;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Iqms.Extensions;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionResponseResolvers
{
    public async Task<GetUserProfileResponse?> ResolveInspectionLead(
        [Parent] GetInspectionResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.InspectionLeadId is null ? null : await loader.LoadAsync(parent.InspectionLeadId.Value, cancellationToken);

    public async Task<GetInspectionAgencyProfileResponse> ResolveInspectionAgency(
        [Parent] GetInspectionResponse parent,
        TenantProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        (await loader.LoadAsync(parent.InspectionAgencyId, cancellationToken)).ToInspectionAgencyProfile();

    public async Task<GetInspectionTypeResponse> ResolveInspectionType(
        [Parent] GetInspectionResponse parent,
        InspectionTypesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectionTypeId, cancellationToken);

    public async Task<GetEntityResponse> ResolveInspectedEntity(
        [Parent] GetInspectionResponse parent,
        EntitiesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectedEntityId, cancellationToken);

    public async Task<GetInspectionLicenseResponse> ResolveInspectionLicense(
        [Parent] GetInspectionResponse parent,
        InspectionLicensesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectionLicenceId, cancellationToken);

    public async Task<GetInspectionScopeResponse> ResolveScope(
        [Parent] GetInspectionResponse parent,
        InspectionScopesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);

    public async Task<IReadOnlyList<GetInspectionEventResponse>> ResolveEvents(
        [Parent] GetInspectionResponse parent,
        [Service] InspectionEventsGroupDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);

    public async Task<GetInspectionEventResponse> ResolveEvent(
        [Argument] Guid id,
        [Parent] GetInspectionResponse parent,
        InspectionEventsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((parent.Id, id), cancellationToken);

    public async Task<IReadOnlyList<GetUserProfileResponse>> ResolveInspectors(
        [Parent] GetInspectionResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.InspectorIds], cancellationToken);

    public async Task<IReadOnlyList<GetIssueResponse>?> ResolveIssues(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        [Service] IssuesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var issues = await client.GetInspectionIssuesAsync(parent.Id, cancellationToken);

        return await loader.LoadAsync([..issues.IssueIds], cancellationToken);
    }

    public async Task<IReadOnlyList<GetDistributionListUsersResponseUser>> ResolveDistributionList(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        CancellationToken cancellationToken = default)
    {
        var distributionListUsers = await client.GetDistributionListUsersAsync(parent.Id, cancellationToken);

        return [..distributionListUsers.Users];
    }

    public async Task<IReadOnlyList<GetObservationResponse>> ResolveObservations(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        ObservationsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var observations = await client.GetInspectionObservationsAsync(parent.Id, cancellationToken);

        return await loader.LoadAsync([..observations.ObservationIds], cancellationToken);
    }

    public async Task<IReadOnlyList<Guid>> ResolveRequestIds(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        CancellationToken cancellationToken = default)
    {
        var requests = await client.GetInspectionRequestsAsync(parent.Id, cancellationToken);

        return [..requests.RequestIds];
    }

    public async Task<IReadOnlyList<Guid>> ResolvePreInspectionRequestIds(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        CancellationToken cancellationToken = default)
    {
        var requests = await client.GetPreInspectionRequestsAsync(parent.Id, cancellationToken);

        return [..requests.RequestIds];
    }

    public async Task<IReadOnlyList<GetReviewResponse>> ResolveReviews(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        ReviewsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var reviews = await client.GetInspectionReviewsAsync(parent.Id, cancellationToken);

        return await loader.LoadAsync([..reviews.ReviewIds], cancellationToken);
    }

    public async Task<IReadOnlyList<GetInspectorSuggestionResponse>> ResolveInspectorSuggestions(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        InspectorSuggestionsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectorSuggestions = await client.GetInspectionInspectorSuggestionsAsync(parent.Id, cancellationToken);

        return await loader.LoadAsync([..inspectorSuggestions.InspectorSuggestionIds], cancellationToken);
    }

    public async Task<IReadOnlyList<GetLessonLearnedResponse>> ResolveLessonsLearned(
        [Parent] GetInspectionResponse parent,
        [Service] IIqmsClient client,
        LessonsLearnedDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var lessonsLearned = await client.GetInspectionLessonsLearnedAsync(parent.Id, cancellationToken);

        return await loader.LoadAsync([..lessonsLearned.LessonsLearnedIds], cancellationToken);
    }

    public async Task<GetInspectionAreaSnapshotResponse> ResolveInspectionAreaSnapshot(
        [Parent] GetInspectionResponse parent,
        InspectionAreaSnapshotsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);

    public async Task<IReadOnlyList<GetInspectionTeamMemberResponse>> ResolveTeamMembers(
        [Parent] GetInspectionResponse parent,
        InspectionTeamMembersGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);

    public async Task<IReadOnlyList<GetTaskResponse>> ResolvePreInspectionTasks(
        [Parent] GetInspectionResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.PreInspectionActionPlanId is null ? [] : await loader.LoadAsync(parent.PreInspectionActionPlanId.Value, cancellationToken);

    public async Task<IReadOnlyList<GetTaskResponse>> ResolveInspectionTasks(
        [Parent] GetInspectionResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.InspectionActionPlanId is null ? [] : await loader.LoadAsync(parent.InspectionActionPlanId.Value, cancellationToken);

    public async Task<IReadOnlyList<GetTaskResponse>> ResolvePostInspectionTasks(
        [Parent] GetInspectionResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.PostInspectionActionPlanId is null ? [] : await loader.LoadAsync(parent.PostInspectionActionPlanId.Value, cancellationToken);

    public async Task<IReadOnlyList<GetTaskResponse>> ResolveInspectionCloseOutTasks(
        [Parent] GetInspectionResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.InspectionCloseOutActionPlanId is null ? [] : await loader.LoadAsync(parent.InspectionCloseOutActionPlanId.Value, cancellationToken);

    public async Task<GetInspectorReportResponse> ResolveInspectorReport(
        [Parent] GetInspectionResponse parent,
        InspectorReportsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);
}
