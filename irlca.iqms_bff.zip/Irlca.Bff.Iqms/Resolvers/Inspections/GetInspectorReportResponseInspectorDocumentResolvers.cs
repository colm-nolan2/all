﻿using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectorReportResponseInspectorDocumentResolvers
{
    public async Task<GetUserProfileResponse?> ResolveUploadedBy(
        [Parent] GetInspectorReportResponseInspectorDocument parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.UploadedBy.HasValue ? await loader.LoadAsync(parent.UploadedBy.Value, cancellationToken) : null;

    public async Task<GetUserProfileResponse?> ResolveInspector(
        [Parent] GetInspectorReportResponseInspectorDocument parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.InspectorId.HasValue ? await loader.LoadAsync(parent.InspectorId.Value, cancellationToken) : null;

    public async Task<GetDocumentDetailsResponse?> ResolveDocument(
        [Parent] GetInspectorReportResponseInspectorDocument parent,
        DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.DocumentId.HasValue ? await loader.LoadAsync(parent.DocumentId.Value, cancellationToken) : null;
}
