﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionAreaSnapshotResponseResolvers
{
    public async Task<IReadOnlyList<GetInspectionAreaSnapshotRoleResponse>> ResolveRoles(
        [Parent] GetInspectionAreaSnapshotResponse parent,
        InspectionAreaSnapshotRolesGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectionId, cancellationToken);
}
