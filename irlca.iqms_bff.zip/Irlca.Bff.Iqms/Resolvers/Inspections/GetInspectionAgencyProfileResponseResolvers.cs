﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionAgencyProfileResponseResolvers
{
    public async Task<IReadOnlyList<GetUserProfileResponse>> ResolveInspectors(
        [Parent] GetTenantProfileResponse parent,
        [Service] IIqmsClient client,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectors = await client.GetInspectionAgencyInspectorsAsync(parent.TenantId, cancellationToken);

        return await loader.LoadAsync([..inspectors.Inspectors.Select(x => x.Id)], cancellationToken);
    }
}
