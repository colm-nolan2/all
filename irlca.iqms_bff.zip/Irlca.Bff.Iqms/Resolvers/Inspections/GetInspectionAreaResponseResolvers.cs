﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionAreaResponseResolvers
{
    public async Task<IReadOnlyList<GetInspectionAreaRoleResponse>> ResolveRoles(
        [Parent] GetInspectionAreaResponse parent,
        [Service] InspectionAreaRolesGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);
}
