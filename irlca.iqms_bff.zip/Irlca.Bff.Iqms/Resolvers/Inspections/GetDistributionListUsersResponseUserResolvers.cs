﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetDistributionListUsersResponseUserResolvers
{
    public async Task<GetUserProfileResponse> ResolveUser(
        [Parent] GetDistributionListUsersResponseUser parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.UserId, cancellationToken);
}
