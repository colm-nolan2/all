﻿using Irlca.Bff.Iqms.DataLoaders.Inspections;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Inspections;

public class GetInspectionTeamMemberResponseResolvers
{
    public async Task<GetUserProfileResponse> ResolveUser(
        [Parent] GetInspectionTeamMemberResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.UserId, cancellationToken);

    public async Task<GetInspectionAreaSnapshotRoleResponse> ResolveRole(
        [Parent] GetInspectionTeamMemberResponse parent,
        InspectionAreaSnapshotRolesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((parent.InspectionId, parent.RoleId), cancellationToken);
}
