﻿using Irlca.Bff.Iqms.DataLoaders.Comments;
using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.Tasks;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Issues;

public class GetIssueAssessmentResponseResolvers
{
    public async Task<GetUserProfileResponse?> ResolveClassifiedBy(
        [Parent] GetIssueAssessmentResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.ClassificationById.HasValue ? await loader.LoadAsync(parent.ClassificationById.Value, cancellationToken) : null;

    public async Task<GetUserProfileResponse?> ResolveCoordinator(
        [Parent] GetIssueAssessmentResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.CoordinatorId.HasValue ? await loader.LoadAsync(parent.CoordinatorId.Value, cancellationToken) : null;

    public async Task<GetUserProfileResponse?> ResolveReviewer(
        [Parent] GetIssueAssessmentResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.ReviewerId.HasValue ? await loader.LoadAsync(parent.ReviewerId.Value, cancellationToken) : null;

    public async Task<IReadOnlyList<GetDocumentDetailsResponse>> ResolveAttachments(
        [Parent] GetIssueAssessmentResponse parent,
        [Service] DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.AttachmentIds], cancellationToken);

    public async Task<IReadOnlyList<GetCommentResponse>> ResolveComments(
        [Parent] GetIssueAssessmentResponse parent,
        [Service] CommentsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.CommentIds], cancellationToken);

    public async Task<IReadOnlyList<GetTaskResponse>> ResolveTasks(
        [Parent] GetIssueAssessmentResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.ActionPlanId is null ? [] : await loader.LoadAsync(parent.ActionPlanId.Value, cancellationToken);
}
