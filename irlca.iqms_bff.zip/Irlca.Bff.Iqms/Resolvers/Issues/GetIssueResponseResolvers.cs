﻿using Irlca.Bff.Iqms.DataLoaders.Issues;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Issues;

public class GetIssueResponseResolvers
{
    public async Task<GetUserProfileResponse> ResolveRaisedBy(
        [Parent] GetIssueResponse parent,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.RaisedById, cancellationToken);

    public async Task<GetIssueAssessmentResponse> ResolveLatestIssueAssessment(
        [Parent] GetIssueResponse parent,
        IssueAssessmentsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((parent.Id, parent.LatestIssueAssessmentId), cancellationToken);
}
