﻿using Irlca.Bff.Iqms.DataLoaders.Comments;
using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.Tasks;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Observations;

public class GetObservationResponseResolvers
{
    public async Task<GetUserProfileResponse> ResolveInspector(
        [Parent] GetObservationResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectorId, cancellationToken);

    public async Task<GetUserProfileResponse?> ResolveCoordinator(
        [Parent] GetObservationResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.CoordinatorId.HasValue ? await loader.LoadAsync(parent.CoordinatorId.Value, cancellationToken) : null;

    public async Task<GetUserProfileResponse?> ResolveReviewer(
        [Parent] GetObservationResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.ReviewerId.HasValue ? await loader.LoadAsync(parent.ReviewerId.Value, cancellationToken) : null;

    public async Task<GetUserProfileResponse> ResolveRaisedBy(
        [Parent] GetObservationResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.RaisedById, cancellationToken);

    public async Task<IReadOnlyList<GetDocumentDetailsResponse>> ResolveAttachments(
        [Parent] GetObservationResponse parent,
        DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.AttachmentIds], cancellationToken);

    public async Task<IReadOnlyList<GetCommentResponse>> ResolveComments(
        [Parent] GetObservationResponse parent,
        CommentsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.CommentIds], cancellationToken);

    public async Task<IReadOnlyList<GetTaskResponse>> ResolveTasks(
        [Parent] GetObservationResponse parent,
        ActionPlanTasksGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        parent.ActionPlanId is null ? [] : await loader.LoadAsync(parent.ActionPlanId.Value, cancellationToken);
}
