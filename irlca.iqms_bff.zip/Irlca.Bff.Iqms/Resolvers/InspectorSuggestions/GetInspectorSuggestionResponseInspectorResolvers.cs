﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.InspectorSuggestions;

public class GetInspectorSuggestionResponseInspectorResolvers
{
    public async Task<GetUserProfileResponse> ResolveInspector(
        [Parent] GetInspectorSuggestionResponseInspector parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectorId, cancellationToken);

    public async Task<GetInspectionAgencyProfileResponse> ResolveInspectionAgency(
        [Parent] GetInspectorSuggestionResponseInspector parent,
        InspectionAgencyProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.InspectionAgencyId, cancellationToken);
}
