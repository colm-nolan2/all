﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.Reviews;

public class GetReviewResponseResolvers
{
    public async Task<GetUserProfileResponse> ResolveOwner(
        [Parent] GetReviewResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.OwnerId, cancellationToken);

    public async Task<GetUserProfileResponse> ResolveRaisedBy(
        [Parent] GetReviewResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.RaisedById, cancellationToken);
}
