﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.UserGroups;

public class GetUserGroupResponseResolvers
{
    public async Task<IReadOnlyList<GetUserProfileResponse>> ResolveUsers(
        [Parent] GetUserGroupResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync([..parent.Users.Select(x => x.UserId)], cancellationToken);
}
