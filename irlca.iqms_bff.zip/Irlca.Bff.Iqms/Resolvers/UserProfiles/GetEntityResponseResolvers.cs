﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.UserProfiles;

public class GetEntityResponseResolvers
{
    public async Task<IReadOnlyList<GetDepartmentResponse>?> ResolveDepartments(
        [Parent] GetEntityResponse parent,
        [Service] IIqmsClient client,
        DepartmentsGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);
}
