﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.UserProfiles;

public class GetDepartmentResponseResolvers
{
    public async Task<IReadOnlyList<GetCompanyRoleResponse>?> ResolveCompanyRoles(
        [Parent] GetDepartmentResponse parent,
        CompanyRolesGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((parent.EntityId, parent.Id), cancellationToken);

    public async Task<IReadOnlyList<GetProcessRoleResponse>?> ResolveProcessRoles(
        [Parent] GetDepartmentResponse parent,
        ProcessRolesGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((parent.EntityId, parent.Id), cancellationToken);
}
