﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.UserProfiles;

public class GetUserProfilesResponseResolvers
{
    public async Task<IReadOnlyList<GetRoleResponse>?> ResolveRoles(
        [Parent] GetUserProfileResponse parent,
        [Service] IIqmsClient client,
        [Service] RolesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var roleAssignments = await client.GetUserRolesAsync(parent.UserId, cancellationToken);

        return await loader.LoadAsync([..roleAssignments.Roles.Select(x => x.Id)], cancellationToken);
    }
}
