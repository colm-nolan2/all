﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.LessonsLearned;

public class GetLessonsLearnedSharedEntityResolvers
{
    public async Task<GetEntityResponse> ResolveEntity(
        [Parent] GetLessonsLearnedSharedEntityResponse parent,
        EntitiesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.EntityId, cancellationToken);
}
