﻿using Irlca.Bff.Iqms.DataLoaders.LessonsLearned;
using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Resolvers.LessonsLearned;

public class GetLessonLearnedResponseResolvers
{
    public async Task<GetUserProfileResponse> ResolveRaisedBy(
        [Parent] GetLessonLearnedResponse parent,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.RaisedById, cancellationToken);

    public async Task<IReadOnlyList<GetLessonsLearnedSharedEntityResponse>> ResolveSharedEntity(
        [Parent] GetLessonLearnedResponse parent,
        LessonsLearnedSharedEntitiesGroupedDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(parent.Id, cancellationToken);
}
