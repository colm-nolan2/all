﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetInspectionAgencyProfileResponse>> GetInspectionAgenciesAsync(
        [Service] IIqmsClient client,
        [Service] InspectionAgencyProfilesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var inspectionAgencies = await client.GetInspectionAgenciesAsync(cancellationToken);

        var result = await loader.LoadAsync([..inspectionAgencies.InspectionAgencyIds], cancellationToken);

        return result;
    }
}
