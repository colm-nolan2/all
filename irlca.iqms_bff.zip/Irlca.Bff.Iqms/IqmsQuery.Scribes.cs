﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetUserProfileResponse>> GetScribeCompanyMembersAsync(
        Guid id,
        [Service] IIqmsClient client,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var scribe = await client.GetScribeAsync(id, cancellationToken);

        return await loader.LoadAsync([..scribe.CompanyMembers], cancellationToken);
    }

    public async Task<IReadOnlyList<GetUserProfileResponse>> GetScribeInspectionAgencyMembersAsync(
        Guid id,
        [Service] IIqmsClient client,
        [Service] UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var scribe = await client.GetScribeAsync(id, cancellationToken);

        return await loader.LoadAsync([..scribe.InspectionAgencyMembers], cancellationToken);
    }
}
