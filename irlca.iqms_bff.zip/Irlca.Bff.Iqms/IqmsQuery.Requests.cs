﻿using Irlca.Bff.Iqms.DataLoaders.Comments;
using Irlca.Bff.Iqms.DataLoaders.DocumentsManager;
using Irlca.Bff.Iqms.DataLoaders.Issues;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetDocumentDetailsResponse>> GetRequestAttachmentsAsync(
        Guid id,
        [Service] IIqmsClient client,
        DocumentDetailsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var result = await client.GetRequestAttachmentsAsync(id, cancellationToken);

        return await loader.LoadAsync([..result.AttachmentIds], cancellationToken);
    }

    public async Task<IReadOnlyList<GetCommentResponse>> GetRequestCommentsAsync(
        Guid id,
        [Service] IIqmsClient client,
        CommentsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var result = await client.GetRequestCommentsAsync(id, cancellationToken);

        return await loader.LoadAsync([..result.CommentIds], cancellationToken);
    }

    public async Task<IReadOnlyList<GetIssueResponse?>> GetRequestIssuesAsync(
        Guid id,
        [Service] IIqmsClient client,
        IssuesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var result = await client.GetRequestIssuesAsync(id, cancellationToken);

        return await loader.LoadAsync([..result.IssueIds], cancellationToken);
    }
}
