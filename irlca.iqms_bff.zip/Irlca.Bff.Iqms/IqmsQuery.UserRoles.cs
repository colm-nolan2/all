﻿using Irlca.Bff.Iqms.DataLoaders.TenantsManagement;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetRoleResponse>> GetUserRolesAsync(
        Guid id,
        [Service] IIqmsClient client,
        RolesDataLoader rolesLoader,
        CancellationToken cancellationToken = default)
    {
        var userRoles = await client.GetUserRolesAsync(id, cancellationToken);

        return await rolesLoader.LoadAsync([..userRoles.Roles.Select(x => x.Id)], cancellationToken);
    }
}
