﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.Extensions;

public static class GetTenantProfileResponseExtensions
{
    public static GetInspectionAgencyProfileResponse ToInspectionAgencyProfile(this GetTenantProfileResponse profile) =>
        new GetInspectionAgencyProfileResponse
        {
            Address = profile.Address,
            Name = profile.Name,
            PrimaryContact = profile.PrimaryContact,
            Reference = profile.Reference,
            TenantId = profile.TenantId,
            WebAddress = profile.WebAddress,
        };
}
