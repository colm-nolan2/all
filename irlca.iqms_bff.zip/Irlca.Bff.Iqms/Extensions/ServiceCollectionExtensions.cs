﻿using HotChocolate.Diagnostics;
using Irlca.Bff.Iqms.Filters;
using Irlca.Bff.Shared;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Irlca.Bff.Iqms.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddIqmsGraphQL(this IServiceCollection services, IHostEnvironment environment)
    {
        services
            .AddGraphQLServer(Consts.SchemaName)
            .RegisterService<IIqmsClient>()
            .AllowIntrospection(environment.IsDevelopment())
            .AddQueryType<IqmsQuery>()
            .AddIqmsTypes()
            .AddInstrumentation(
                b =>
                {
                    b.IncludeDataLoaderKeys = true;
                    b.IncludeDocument = true;
                    b.RequestDetails = RequestDetails.All;
                    b.Scopes = ActivityScopes.All;
                })
            .AddApolloTracing()
            .InitializeOnStartup();

        services.AddErrorFilter<IqmsApiErrorFilter>();

        return services;
    }
}
