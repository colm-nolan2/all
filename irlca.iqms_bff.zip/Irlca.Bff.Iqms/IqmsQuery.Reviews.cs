﻿using Irlca.Bff.Iqms.DataLoaders.Reviews;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetReviewResponse>> GetReviewsAsync(
        IReadOnlyList<Guid> ids,
        ReviewsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);

    public async Task<GetReviewResponse> GetReviewAsync(
        Guid id,
        ReviewsDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
