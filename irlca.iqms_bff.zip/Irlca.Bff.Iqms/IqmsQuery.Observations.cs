﻿using Irlca.Bff.Iqms.DataLoaders.Observations;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetObservationResponse>> GetObservations(
        [Service] IIqmsClient client,
        ObservationsDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var observations = await client.GetObservationsAsync(cancellationToken);

        return await loader.LoadAsync([..observations.Observations.Select(x => x.Id)], cancellationToken);
    }

    public async Task<GetObservationResponse> GetObservationAsync(Guid id, ObservationsDataLoader loader, CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
