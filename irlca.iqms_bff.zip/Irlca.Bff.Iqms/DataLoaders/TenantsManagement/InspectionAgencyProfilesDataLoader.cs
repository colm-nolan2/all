﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.TenantsManagement;

public class InspectionAgencyProfilesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetInspectionAgencyProfileResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetInspectionAgencyProfileResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetTenantProfileAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result
            .Select(GetInspectionAgencyProfileResponse.FromTenantProfileResponse)
            .ToDictionary(x => x.TenantId);
    }
}
