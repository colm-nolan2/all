﻿using Irlca.Bff.Shared;
using Microsoft.AspNetCore.Http;

namespace Irlca.Bff.Iqms.DataLoaders.TenantsManagement;

public class PermissionsDataLoader(IIqmsClient client, IBatchScheduler scheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetPermissionResponse?>(scheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetPermissionResponse?>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => GetPermissionAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result
            .Where(x => x is not null)
            .ToDictionary(x => x!.Id);
    }

    private async Task<GetPermissionResponse?> GetPermissionAsync(Guid id, CancellationToken cancellationToken)
    {
        try
        {
            return await client.GetPermissionAsync(id, cancellationToken);
        }
        catch (ApiException ex) when (ex.StatusCode == StatusCodes.Status404NotFound)
        {
            return null;
        }
    }
}
