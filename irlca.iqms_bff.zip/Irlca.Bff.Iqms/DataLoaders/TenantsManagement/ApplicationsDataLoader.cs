﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.TenantsManagement;

public class ApplicationsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetApplicationResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetApplicationResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetApplicationAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
