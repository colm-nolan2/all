﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class EntitiesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetEntityResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetEntityResponse>> LoadBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetEntityAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
