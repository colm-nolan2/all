﻿using Irlca.Bff.Shared;
using Microsoft.AspNetCore.Http;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class CompanyRolesGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<(Guid EntityId, Guid DepartmentId), GetCompanyRoleResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<(Guid EntityId, Guid DepartmentId), GetCompanyRoleResponse>> LoadGroupedBatchAsync(
        IReadOnlyList<(Guid EntityId, Guid DepartmentId)> keys,
        CancellationToken cancellationToken)
    {
        var departmentCompanyRolesTasks = keys
            .Select(async x => (Key: x, Response: await client.GetCompanyRolesAsync(x.EntityId, x.DepartmentId, cancellationToken)));

        var departmentCompanyRoles = await Task.WhenAll(departmentCompanyRolesTasks);

        var companyRolesTasks = departmentCompanyRoles
            .SelectMany(x => x.Response.CompanyRoles, (tuple, role) => (tuple.Key, role))
            .Select(async x => (x.Key, Role: await FindCompanyRole(x.role.EntityId, x.role.DepartmentId, x.role.Id, cancellationToken)));

        var result = await Task.WhenAll(companyRolesTasks);

        return result
            .Where(x => x.Role is not null)
            .ToLookup(x => x.Key, x => x.Role!);
    }

    private async Task<GetCompanyRoleResponse?> FindCompanyRole(Guid entityId, Guid departmentId, Guid roleId, CancellationToken cancellationToken)
    {
        try
        {
            return await client.GetCompanyRoleAsync(entityId, departmentId, roleId, cancellationToken);
        }
        catch (ApiException ex) when (ex.StatusCode == StatusCodes.Status404NotFound)
        {
            return null;
        }
    }
}
