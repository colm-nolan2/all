﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class TenantProfilesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetTenantProfileResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetTenantProfileResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetTenantProfileAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.TenantId);
    }
}
