﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class CompanyRolesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid EntityId, Guid DepartmnentId, Guid RoleId), GetCompanyRoleResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid EntityId, Guid DepartmnentId, Guid RoleId), GetCompanyRoleResponse>> LoadBatchAsync(IReadOnlyList<(Guid EntityId, Guid DepartmnentId, Guid RoleId)> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetCompanyRoleAsync(x.EntityId, x.DepartmnentId, x.RoleId, cancellationToken));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => (x.EntityId, x.DepartmentId, RoleId: x.Id));
    }
}
