﻿using Irlca.Bff.Shared;
using Microsoft.AspNetCore.Http;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class DepartmentsGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetDepartmentResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetDepartmentResponse>> LoadGroupedBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetDepartmentsAsync(x, cancellationToken));

        var departments = await Task.WhenAll(tasks);

        var departmentTasks = departments
            .SelectMany(x => x.Departments)
            .Select(x => FindDepartment(x.EntityId, x.Id, cancellationToken));

        var results = await Task.WhenAll(departmentTasks);

        return results
            .Where(x => x is not null)
            .ToLookup(x => x!.EntityId, x => x!);
    }

    private async Task<GetDepartmentResponse?> FindDepartment(Guid entityId, Guid departmentId, CancellationToken cancellationToken)
    {
        try
        {
            return await client.GetDepartmentAsync(entityId, departmentId, cancellationToken);
        }
        catch (ApiException ex) when (ex.StatusCode == StatusCodes.Status404NotFound)
        {
            return null;
        }
    }
}
