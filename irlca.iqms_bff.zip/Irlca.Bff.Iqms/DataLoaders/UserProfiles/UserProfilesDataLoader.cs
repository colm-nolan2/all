﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class UserProfilesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetUserProfileResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetUserProfileResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetUserProfileAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.UserId);
    }
}
