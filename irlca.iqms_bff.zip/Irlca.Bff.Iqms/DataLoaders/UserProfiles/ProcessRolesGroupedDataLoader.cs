﻿using Irlca.Bff.Shared;
using Microsoft.AspNetCore.Http;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class ProcessRolesGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<(Guid EntityId, Guid DepartmentId), GetProcessRoleResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<(Guid EntityId, Guid DepartmentId), GetProcessRoleResponse>> LoadGroupedBatchAsync(
        IReadOnlyList<(Guid EntityId, Guid DepartmentId)> keys,
        CancellationToken cancellationToken)
    {
        var departmentProcessRolesTasks = keys
            .Select(async x => (Key: x, Response: await client.GetProcessRolesAsync(x.EntityId, x.DepartmentId, cancellationToken)));

        var departmentProcessRoles = await Task.WhenAll(departmentProcessRolesTasks);

        var processRolesTasks = departmentProcessRoles
            .SelectMany(x => x.Response.ProcessRoles, (tuple, role) => (tuple.Key, role))
            .Select(async x => (x.Key, Role: await FindProcessRole(x.role.EntityId, x.role.DepartmentId, x.role.Id, cancellationToken)));

        var result = await Task.WhenAll(processRolesTasks);

        return result
            .Where(x => x.Role is not null)
            .ToLookup(x => x.Key, x => x.Role!);
    }

    private async Task<GetProcessRoleResponse?> FindProcessRole(Guid entityId, Guid departmentId, Guid roleId, CancellationToken cancellationToken)
    {
        try
        {
            return await client.GetProcessRoleAsync(entityId, departmentId, roleId, cancellationToken);
        }
        catch (ApiException ex) when (ex.StatusCode == StatusCodes.Status404NotFound)
        {
            return null;
        }
    }
}
