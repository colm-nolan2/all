﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.UserProfiles;

public class ProcessRolesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid EntityId, Guid DepartmnentId, Guid RoleId), GetProcessRoleResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid EntityId, Guid DepartmnentId, Guid RoleId), GetProcessRoleResponse>> LoadBatchAsync(IReadOnlyList<(Guid EntityId, Guid DepartmnentId, Guid RoleId)> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetProcessRoleAsync(x.EntityId, x.DepartmnentId, x.RoleId, cancellationToken));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => (x.EntityId, x.DepartmentId, RoleId: x.Id));
    }
}
