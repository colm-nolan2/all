﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.InspectionScribeStatisticsReport;

public class InspectionScribeStatisticsReportDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid InspectionId, Guid ScribeId), GetInspectionScribeStatisticsReportResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid InspectionId, Guid ScribeId), GetInspectionScribeStatisticsReportResponse>> LoadBatchAsync(IReadOnlyList<(Guid InspectionId, Guid ScribeId)> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetInspectionScribeStatisticsReportAsync(x.InspectionId, x.ScribeId, cancellationToken));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => (x.InspectionId, x.ScribeId));
    }
}
