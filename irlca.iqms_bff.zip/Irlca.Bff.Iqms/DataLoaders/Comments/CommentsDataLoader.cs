﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Comments;

public class CommentsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetCommentResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetCommentResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetCommentAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
