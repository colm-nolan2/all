﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.LessonsLearned;

public class LessonsLearnedSharedEntitiesGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetLessonsLearnedSharedEntityResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetLessonsLearnedSharedEntityResponse>> LoadGroupedBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(async x => (LessonLearnedId: x, Response: await client.GetLessonsLearnedSharedEntitiesAsync(x, cancellationToken)));

        var sharedEntities = await Task.WhenAll(tasks);

        return sharedEntities
            .SelectMany(x => x.Response.LessonsLearnedSharedEntities, (tuple, response) => (tuple.LessonLearnedId, response))
            .ToLookup(x => x.LessonLearnedId, x => x.response);
    }
}
