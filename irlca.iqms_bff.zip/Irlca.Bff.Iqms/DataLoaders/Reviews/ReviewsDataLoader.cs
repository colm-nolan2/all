﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Reviews;

public class ReviewsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetReviewResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetReviewResponse>> LoadBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetReviewAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
