﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Issues;

public class IssuesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetIssueResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetIssueResponse>> LoadBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetIssueAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
