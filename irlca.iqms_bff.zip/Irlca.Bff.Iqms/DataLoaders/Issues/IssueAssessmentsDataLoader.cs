﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Issues;

public class IssueAssessmentsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid IssueId, Guid IssueAssessmentId), GetIssueAssessmentResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid IssueId, Guid IssueAssessmentId), GetIssueAssessmentResponse>> LoadBatchAsync(IReadOnlyList<(Guid IssueId, Guid IssueAssessmentId)> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetIssueAssessmentAsync(x.IssueId, x.IssueAssessmentId, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => (x.IssueId, x.Id));
    }
}
