﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectionAreaRolesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid AreaId, Guid RoleId), GetInspectionAreaRoleResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid AreaId, Guid RoleId), GetInspectionAreaRoleResponse>> LoadBatchAsync(IReadOnlyList<(Guid AreaId, Guid RoleId)> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetInspectionAreaRoleAsync(x.AreaId, x.RoleId, cancellationToken));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => (x.InspectionAreaId, x.Id));
    }
}
