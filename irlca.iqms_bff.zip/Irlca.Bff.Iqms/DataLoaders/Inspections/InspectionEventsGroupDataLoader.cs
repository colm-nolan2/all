﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

[Obsolete("Refactor to not use LinqAsync")]
public class InspectionEventsGroupDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetInspectionEventResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetInspectionEventResponse>> LoadGroupedBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        return await keys
            .ToAsyncEnumerable()
            .SelectAwaitWithCancellation(async (x, ct) => await client.GetInspectionEventsAsync(x, ct))
            .SelectMany(
                x => x.Events.ToAsyncEnumerable(),
                (response, @event) => (response.InspectionId, @event.EventId))
            .SelectAwaitWithCancellation(async (x, ct) => await client.GetInspectionEventAsync(x.InspectionId, x.EventId, ct))
            .ToLookupAsync(x => x.InspectionId, cancellationToken);
    }
}
