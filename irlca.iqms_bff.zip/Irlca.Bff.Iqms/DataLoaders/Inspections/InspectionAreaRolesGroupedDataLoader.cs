﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

[Obsolete("Refactor to not use LinqAsync")]
public class InspectionAreaRolesGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetInspectionAreaRoleResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetInspectionAreaRoleResponse>> LoadGroupedBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken) =>
        await keys
            .ToAsyncEnumerable()
            .SelectAwaitWithCancellation(async (x, ct) => await client.GetInspectionAreaRolesAsync(x, ct))
            .SelectMany(
                x => x.RoleIds.ToAsyncEnumerable(),
                (response, roleId) => (response.InspectionAreaId, RoleId: roleId))
            .SelectAwaitWithCancellation(async (x, ct) => await client.GetInspectionAreaRoleAsync(x.InspectionAreaId, x.RoleId, ct))
            .ToLookupAsync(x => x.InspectionAreaId, cancellationToken);
}
