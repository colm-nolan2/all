﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectionTeamMembersGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetInspectionTeamMemberResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetInspectionTeamMemberResponse>> LoadGroupedBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var result = new List<(Guid, GetInspectionTeamMemberResponse)>();

        var tasks = keys.Select(async x => (InspectionId: x, Response: await client.GetInspectionTeamMembersAsync(x, cancellationToken)));

        var inspectionTeamMembers = await Task.WhenAll(tasks);

        foreach (var (inspectionId, response) in inspectionTeamMembers)
        {
            var teamMemberTasks = response.TeamMemberIds.Select(
                x => client.GetInspectionTeamMemberAsync(inspectionId, x, cancellationToken));

            var teamMembers = await Task.WhenAll(teamMemberTasks);

            result.AddRange(teamMembers.Select(x => (InspectionId: inspectionId, x)));
        }

        return result.ToLookup(x => x.Item1, x => x.Item2);
    }
}
