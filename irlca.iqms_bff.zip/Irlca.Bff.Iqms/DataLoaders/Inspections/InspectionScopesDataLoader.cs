﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectionScopesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetInspectionScopeResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetInspectionScopeResponse>> LoadBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(async x => (Key: x, Scope: await client.GetInspectionScopeAsync(x, cancellationToken)));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => x.Key, x => x.Scope);
    }
}
