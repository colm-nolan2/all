﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectorReportsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetInspectorReportResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetInspectorReportResponse>> LoadBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(async x => await client.GetInspectorReportAsync(x, cancellationToken));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => x.InspectionId);
    }
}
