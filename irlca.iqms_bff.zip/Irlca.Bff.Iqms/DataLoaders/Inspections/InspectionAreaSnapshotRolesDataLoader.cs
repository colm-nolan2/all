﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectionAreaSnapshotRolesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid InspectionId, Guid RoleId), GetInspectionAreaSnapshotRoleResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid InspectionId, Guid RoleId), GetInspectionAreaSnapshotRoleResponse>> LoadBatchAsync(IReadOnlyList<(Guid InspectionId, Guid RoleId)> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(async x => (Key: x, Response: await client.GetInspectionAreaSnapshotRoleAsync(x.InspectionId, x.RoleId, cancellationToken)));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Key, x => x.Response);
    }
}
