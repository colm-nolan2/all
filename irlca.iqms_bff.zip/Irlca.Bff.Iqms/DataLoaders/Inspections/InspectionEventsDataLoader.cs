﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectionEventsDataLoader(IBatchScheduler batchScheduler, IIqmsClient client, DataLoaderOptions? options = null)
    : BatchDataLoader<(Guid InspectionId, Guid EventId), GetInspectionEventResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<(Guid InspectionId, Guid EventId), GetInspectionEventResponse>> LoadBatchAsync(
        IReadOnlyList<(Guid InspectionId, Guid EventId)> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetInspectionEventAsync(x.InspectionId, x.EventId, cancellationToken));

        var results = await Task.WhenAll(tasks);

        return results.ToDictionary(x => (x.InspectionId, x.Id));
    }
}
