﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

[Obsolete("Refactor to not use LinqAsync")]
public class InspectionAreaSnapshotRolesGroupedDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetInspectionAreaSnapshotRoleResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetInspectionAreaSnapshotRoleResponse>> LoadGroupedBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken) =>
        await keys
            .ToAsyncEnumerable()
            .SelectAwaitWithCancellation(async (x, ct) => await client.GetInspectionAreaSnapshotAsync(x, ct))
            .SelectMany(x => x.RoleIds.ToAsyncEnumerable(), (response, roleId) => (response.InspectionId, RoleId: roleId))
            .SelectAwaitWithCancellation(async (x, ct) => (x.InspectionId, Role: await client.GetInspectionAreaSnapshotRoleAsync(x.InspectionId, x.RoleId, ct)))
            .ToLookupAsync(x => x.InspectionId, x => x.Role, cancellationToken);
}
