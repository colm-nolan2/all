﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Inspections;

public class InspectionLicensesDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetInspectionLicenseResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetInspectionLicenseResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetInspectionLicenseAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
