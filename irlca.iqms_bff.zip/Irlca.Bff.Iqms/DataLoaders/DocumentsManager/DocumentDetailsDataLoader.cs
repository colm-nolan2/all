﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.DocumentsManager;

public class DocumentDetailsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetDocumentDetailsResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetDocumentDetailsResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetDocumentDetailsAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
