﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Tasks;

public class ActionPlanTasksGroupedDataLoader(IIqmsClient client, TasksDataLoader loader, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : GroupedDataLoader<Guid, GetTaskResponse>(batchScheduler, options)
{
    protected override async Task<ILookup<Guid, GetTaskResponse>> LoadGroupedBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var result = new List<(Guid, GetTaskResponse)>();

        var actionPlanTasks = keys.Select(x => client.GetActionPlanAsync(x, cancellationToken));

        var actionPlans = await Task.WhenAll(actionPlanTasks);

        foreach (var actionPlan in actionPlans)
        {
            var tasks = await loader.LoadAsync([..actionPlan.TaskIds], cancellationToken);

            result.AddRange(tasks.Select(x => (actionPlan.Id, x)));
        }

        return result.ToLookup(x => x.Item1, x => x.Item2);
    }
}
