﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Tasks;

public class ActionPlansDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetActionPlanResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetActionPlanResponse>> LoadBatchAsync(IReadOnlyList<Guid> keys, CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetActionPlanAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
