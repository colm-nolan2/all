﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms.DataLoaders.Observations;

public class ObservationsDataLoader(IIqmsClient client, IBatchScheduler batchScheduler, DataLoaderOptions? options = null)
    : BatchDataLoader<Guid, GetObservationResponse>(batchScheduler, options)
{
    protected override async Task<IReadOnlyDictionary<Guid, GetObservationResponse>> LoadBatchAsync(
        IReadOnlyList<Guid> keys,
        CancellationToken cancellationToken)
    {
        var tasks = keys.Select(x => client.GetObservationAsync(x, cancellationToken));

        var result = await Task.WhenAll(tasks);

        return result.ToDictionary(x => x.Id);
    }
}
