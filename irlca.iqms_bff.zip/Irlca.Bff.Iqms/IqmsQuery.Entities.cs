﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<IReadOnlyList<GetEntityResponse>> GetEntitiesAsync(
        [Service] IIqmsClient client,
        EntitiesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var entities = await client.GetEntitiesAsync(cancellationToken);

        var ids = entities.Entities.Select(x => x.Id);

        return await loader.LoadAsync([..ids], cancellationToken);
    }

    public async Task<GetEntityResponse?> GetEntityAsync(
        Guid id,
        EntitiesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
