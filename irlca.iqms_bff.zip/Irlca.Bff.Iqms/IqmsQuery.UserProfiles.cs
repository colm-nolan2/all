﻿using Irlca.Bff.Iqms.DataLoaders.UserProfiles;
using Irlca.Bff.Shared;

namespace Irlca.Bff.Iqms;

public partial class IqmsQuery
{
    public async Task<GetUserProfileResponse?> FindUserAsync(Guid? id, UserProfilesDataLoader loader, CancellationToken cancellationToken = default) =>
        id.HasValue ? await loader.LoadAsync(id.Value, cancellationToken) : null;

    public async Task<GetUserProfileResponse?> GetUserAsync(
        Guid id,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetUserProfileResponse>> GetUsersAsync(
        IReadOnlyCollection<Guid> ids,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);

    public async Task<IReadOnlyList<GetUserProfileResponse>> GetAllUsersAsync(
        [Service] IIqmsClient client,
        UserProfilesDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var users = await client.GetUserProfilesAsync(cancellationToken);

        return await loader.LoadAsync([..users.UserProfiles.Select(x => x.UserId)], cancellationToken);
    }

    public async Task<GetCompanyRoleResponse> GetCompanyRoleAsync(
        Guid entityId,
        Guid departmentId,
        Guid roleId,
        CompanyRolesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((entityId, departmentId, roleId), cancellationToken);

    public async Task<GetProcessRoleResponse> GetProcessRoleAsync(
        Guid entityId,
        Guid departmentId,
        Guid roleId,
        ProcessRolesDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync((entityId, departmentId, roleId), cancellationToken);
}
