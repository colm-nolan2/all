﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Irlca.Bff.Inspections.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInspectionsGraphQL(this IServiceCollection services, IHostEnvironment environment)
    {
        services
            .AddGraphQLServer("Inspections")
            .AllowIntrospection(environment.IsDevelopment())
            .AddQueryType<InspectionsQuery>();

        return services;
    }
}
