﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.Inspections;

public class InspectionsQuery
{
    
}
