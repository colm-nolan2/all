﻿using Azure.Monitor.OpenTelemetry.AspNetCore;
using Irlca.Bff.Host.Providers;
using Irlca.Bff.Host.Telemetry;
using OpenTelemetry;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace Irlca.Bff.Host.Extensions;

public static partial class ServiceCollectionExtensions
{
    public static IServiceCollection AddBffOpenTelemetry(this IServiceCollection services)
    {
        var attributes = new Dictionary<string, object>
        {
            [DiagnosticsNames.ServiceVersion] = ServiceVersionProvider.ServiceVersion,
        };

        services.AddOpenTelemetry()
            .ConfigureResource(
                b => b
                    .AddAzureContainerAppsDetector()
                    .AddAttributes(attributes))
            .WithMetrics(
                b =>
                {
                    b.AddAspNetCoreInstrumentation();
                    b.AddHttpClientInstrumentation();
                })
            .WithTracing(
                b =>
                {
                    b.AddHotChocolateInstrumentation();
                    b.AddAspNetCoreInstrumentation();
                    b.AddHttpClientInstrumentation();
                })
            .UseAzureMonitor()
            .UseOtlpExporter();

        return services;
    }
}
