﻿using System.Diagnostics;
using System.Security.Claims;
using Irlca.Bff.Host.Telemetry;

namespace Irlca.Bff.Host.Extensions;

public static class ActivityExtensions
{
    public static void EnrichWithClaimsPrincipal(this Activity activity, ClaimsPrincipal? principal)
    {
        if (principal is null)
        {
            return;
        }

        var userId = principal.FindFirstValue("uid");
        var tenantId = principal.FindFirstValue("tid");
        var entityId = principal.FindFirstValue("eid");

        activity.AddTag(DiagnosticsNames.AuthenticatedUserId, userId);
        activity.AddTag(DiagnosticsNames.IrlcaTenantId, tenantId);
        activity.AddTag(DiagnosticsNames.IrlcaEntityId, entityId);
        activity.AddTag(DiagnosticsNames.IrlcaUserId, userId);
    }
}
