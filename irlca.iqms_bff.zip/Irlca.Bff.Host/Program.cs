﻿#pragma warning disable CA1506
// See https://aka.ms/new-console-template for more information
// NSwagCSharp parameters https://github.com/RicoSuter/NSwag/wiki/NSwag-Configuration-Document
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using HotChocolate.AspNetCore;
using Irlca.Bff.Gateway.Extensions;
using Irlca.Bff.Host.Extensions;
using Irlca.Bff.Iqms.Extensions;
using Irlca.Bff.Shared.Extensions;
using Microsoft.Net.Http.Headers;
using Serilog;

JwtSecurityTokenHandler.DefaultMapInboundClaims = false;

Log.Logger = new LoggerConfiguration()
    .WriteTo.Debug(formatProvider: CultureInfo.InvariantCulture)
    .WriteTo.Console(formatProvider: CultureInfo.InvariantCulture) // Remove in production
    .Enrich.FromLogContext()
    .Enrich.WithEnvironmentName()
    .Enrich.WithMachineName()
    .Enrich.WithAssemblyName()
    .Enrich.WithAssemblyVersion()
    .CreateBootstrapLogger();

var builder = WebApplication.CreateBuilder(args);

builder.Logging
    .AddOpenTelemetry()
    .AddSerilog();

builder.Services.AddSerilog(
    (services, configuration) => configuration
        .ReadFrom.Configuration(builder.Configuration)
        .ReadFrom.Services(services)
        .WriteTo.Debug(formatProvider: CultureInfo.InvariantCulture)
        .WriteTo.Console(formatProvider: CultureInfo.InvariantCulture)
        .Enrich.FromLogContext()
        .Enrich.WithEnvironmentName()
        .Enrich.WithMachineName()
        .Enrich.WithAssemblyName()
        .Enrich.WithAssemblyVersion());

builder.Services.AddBffOpenTelemetry();

builder.Services.AddBffAuthentication(builder.Configuration);

builder.Services.AddHealthChecks();

builder.Services.AddHeaderPropagation(o => o.Headers.Add(HeaderNames.Authorization));

builder.Services
    .AddHttpClient()
    .AddHttpContextAccessor()
    .AddIqmsApi(builder.Configuration);

builder.Services
    .AddIqmsGraphQL(builder.Environment)
    .AddGraphQLGateway(builder.Configuration, builder.Environment);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseHeaderPropagation();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapHealthChecks("/healthz")
    .AllowAnonymous();

app.MapGraphQL()
    .WithOptions(
        new GraphQLServerOptions
        {
            EnableSchemaRequests = app.Environment.IsDevelopment(),
            Tool =
            {
                Enable = app.Environment.IsDevelopment(),
            },
        })
    .RequireAuthorization();

app.MapBananaCakePop().AllowAnonymous();

await app.RunAsync();
