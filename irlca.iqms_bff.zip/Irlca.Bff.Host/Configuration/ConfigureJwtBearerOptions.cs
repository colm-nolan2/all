﻿using System.Diagnostics;
using System.Security.Claims;
using Irlca.Bff.Host.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Irlca.Bff.Host.Configuration;

public class ConfigureJwtBearerOptions(IOptions<AuthenticationOptions> options) : IConfigureNamedOptions<JwtBearerOptions>
{
    private readonly AuthenticationOptions _authenticationOptions = options.Value;

    public void Configure(JwtBearerOptions options)
    {
        Configure(JwtBearerDefaults.AuthenticationScheme, options);
    }

    public void Configure(string? name, JwtBearerOptions options)
    {
        options.Authority = $"https://{_authenticationOptions.Domain}";
        options.Audience = _authenticationOptions.Audience;

        options.TokenValidationParameters = new TokenValidationParameters
        {
            NameClaimType = ClaimTypes.NameIdentifier,
            ValidAudience = _authenticationOptions.Audience,
            ValidIssuer = $"https://{_authenticationOptions.Domain}/",
            ValidateIssuerSigningKey = true,
        };

        options.Events = new JwtBearerEvents
        {
            OnTokenValidated = context =>
            {
                Activity.Current?.EnrichWithClaimsPrincipal(context.Principal);
                return Task.CompletedTask;
            },
        };
    }
}
