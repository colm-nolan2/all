﻿using System.ComponentModel.DataAnnotations;

namespace Irlca.Bff.Host.Configuration;

public sealed class AuthenticationOptions
{
    public const string SectionName = "Authentication";

    [Required]
    public string Audience { get; init; } = string.Empty;

    [Required]
    public string Domain { get; init; } = string.Empty;
}
