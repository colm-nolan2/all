﻿namespace Irlca.Bff.Host.Providers;

internal static class ServiceVersionProvider
{
    internal static readonly string ServiceVersion = typeof(ServiceVersionProvider).Assembly.GetName()?.Version?.ToString(3) ?? "0.0.0";
}
