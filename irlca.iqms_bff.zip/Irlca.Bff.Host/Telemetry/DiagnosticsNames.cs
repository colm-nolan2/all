﻿namespace Irlca.Bff.Host.Telemetry;

internal static class DiagnosticsNames
{
    public const string AuthenticatedUserId = "enduser.id";

    public const string IrlcaTenantId = "irlca.iqms.tenant.id";
    public const string IrlcaEntityId = "irlca.iqms.entity.id";
    public const string IrlcaUserId = "irlca.iqms.user.id";

    public const string ServiceVersion = "irlca.service.version";
}
