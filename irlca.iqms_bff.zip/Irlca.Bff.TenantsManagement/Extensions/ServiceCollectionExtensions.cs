﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Irlca.Bff.TenantsManagement.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddTenantsManagementGraphQL(this IServiceCollection services, IHostEnvironment environment)
    {
        services
            .AddGraphQLServer("TenantsManagement")
            .AllowIntrospection(environment.IsDevelopment())
            .AddQueryType<TenantsManagementQuery>()
            .AddTenantsManagementTypes();

        return services;
    }
}
