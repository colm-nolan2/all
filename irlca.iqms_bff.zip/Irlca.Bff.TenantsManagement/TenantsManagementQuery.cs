﻿using System.Diagnostics.CodeAnalysis;
using Irlca.Bff.Shared;
using Irlca.Bff.TenantsManagement.DataLoaders;

namespace Irlca.Bff.TenantsManagement;

public class TenantsManagementQuery
{
    public async Task<IReadOnlyList<GetApplicationResponse>> GetApplicationsAsync(
        [Service] IIqmsClient client,
        ApplicationCacheDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var tenantApplications = await client.GetTenantApplicationsAsync(cancellationToken);

        return await loader.LoadAsync(tenantApplications.ApplicationIds.ToList(), cancellationToken);
    }

    public async Task<GetApplicationResponse> GetApplicationAsync(
        Guid id,
        ApplicationCacheDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetPermissionResponse?>> GetPermissionsAsync(
        IReadOnlyList<Guid> ids,
        PermissionCacheDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(ids, cancellationToken);

    public async Task<GetPermissionResponse?> GetPermissionAsync(
        Guid id,
        PermissionCacheDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetRoleResponse>> GetRolesAsync(
        [Service] IIqmsClient client,
        RoleCacheDataLoader loader,
        CancellationToken cancellationToken = default)
    {
        var roles = await client.GetRolesAsync(cancellationToken);

        return await loader.LoadAsync(roles.RoleIds.ToList(), cancellationToken);
    }

    public async Task<GetRoleResponse> GetRoleAsync(
        Guid id,
        RoleCacheDataLoader loader,
        CancellationToken cancellationToken = default) =>
        await loader.LoadAsync(id, cancellationToken);
}
