﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.TenantsManagement.DataLoaders;

public class ApplicationCacheDataLoader : CacheDataLoader<Guid, GetApplicationResponse>
{
    private readonly IIqmsClient _client;

    public ApplicationCacheDataLoader(IIqmsClient client, DataLoaderOptions? options = null)
        : base(options)
    {
        _client = client;
    }

    protected override async Task<GetApplicationResponse> LoadSingleAsync(Guid key, CancellationToken cancellationToken) =>
        await _client.GetApplicationAsync(key, cancellationToken);
}
