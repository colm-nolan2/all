﻿using Irlca.Bff.Shared;
using Microsoft.AspNetCore.Http;

namespace Irlca.Bff.TenantsManagement.DataLoaders;

public class PermissionCacheDataLoader : CacheDataLoader<Guid, GetPermissionResponse?>
{
    private readonly IIqmsClient _client;

    public PermissionCacheDataLoader(IIqmsClient client, DataLoaderOptions? options = null)
        : base(options)
    {
        _client = client;
    }

    protected override async Task<GetPermissionResponse?> LoadSingleAsync(Guid key, CancellationToken cancellationToken)
    {
        try
        {
            return await _client.GetPermissionAsync(key, cancellationToken);
        }
        catch (Irlca.Bff.Shared.ApiException ex) when (ex.StatusCode == StatusCodes.Status404NotFound)
        {
            return null;
        }
    }
}
