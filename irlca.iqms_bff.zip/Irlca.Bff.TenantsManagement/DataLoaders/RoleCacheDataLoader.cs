﻿using Irlca.Bff.Shared;

namespace Irlca.Bff.TenantsManagement.DataLoaders;

public class RoleCacheDataLoader : CacheDataLoader<Guid, GetRoleResponse>
{
    private readonly IIqmsClient _client;

    public RoleCacheDataLoader(IIqmsClient client, DataLoaderOptions? options = null)
        : base(options)
    {
        _client = client;
    }

    protected override async Task<GetRoleResponse> LoadSingleAsync(Guid key, CancellationToken cancellationToken) =>
        await _client.GetRoleAsync(key, cancellationToken);
}
