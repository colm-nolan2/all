﻿using Irlca.Bff.Shared;
using Irlca.Bff.TenantsManagement.DataLoaders;

namespace Irlca.Bff.TenantsManagement.ObjectTypes;

public class GetRoleResponseTypeExtension : ObjectTypeExtension<GetRoleResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetRoleResponse> descriptor)
    {
        descriptor.Ignore(x => x.PermissionIds);

        descriptor
            .Field("permissions")
            .Type<NonNullType<IType>>()
            .Resolve(async (ctx, ct) =>
            {
                var parent = ctx.Parent<GetRoleResponse>();
                var loader = ctx.Service<PermissionCacheDataLoader>();

                var result = await loader.LoadAsync(parent.PermissionIds.ToList(), ct);

                return result.Where(x => x is not null);
            });
    }
}
