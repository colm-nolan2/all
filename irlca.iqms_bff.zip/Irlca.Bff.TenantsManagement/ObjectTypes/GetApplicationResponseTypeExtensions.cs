﻿using Irlca.Bff.Shared;
using Irlca.Bff.TenantsManagement.DataLoaders;

namespace Irlca.Bff.TenantsManagement.ObjectTypes;

public class GetApplicationResponseTypeExtensions : ObjectTypeExtension<GetApplicationResponse>
{
    protected override void Configure(IObjectTypeDescriptor<GetApplicationResponse> descriptor)
    {
        descriptor.Ignore(x => x.PermissionIds);

        descriptor
            .Field("permissions")
            .Resolve(async (ctx, ct) =>
            {
                var parent = ctx.Parent<GetApplicationResponse>();
                var loader = ctx.Service<PermissionCacheDataLoader>();

                return await loader.LoadAsync(parent.PermissionIds.ToList(), ct);
            });
    }
}
