﻿using HotChocolate.Resolvers;
using Irlca.Bff.Shared;

namespace Irlca.Bff.UserProfiles;

public class UserProfilesQuery
{
    public async Task<GetUserProfileResponse> GetUserProfileAsync(
        Guid id,
        IResolverContext context,
        [Service] IIqmsClient client,
        CancellationToken cancellationToken = default) =>
        await context
            .CacheDataLoader<Guid, GetUserProfileResponse>(async (key, token) => await client.GetUserProfileAsync(key, token), "userProfileById")
            .LoadAsync(id, cancellationToken);

    public async Task<IReadOnlyList<GetUserProfileResponse>> GetUserProfilesAsync(
        IReadOnlyCollection<Guid> ids,
        IResolverContext context,
        [Service] IIqmsClient client,
        CancellationToken cancellationToken = default) =>
        await context.CacheDataLoader<Guid, GetUserProfileResponse>(async (key, ct) => await client.GetUserProfileAsync(key, ct), "userProfileById")
            .LoadAsync(ids, cancellationToken);
}
