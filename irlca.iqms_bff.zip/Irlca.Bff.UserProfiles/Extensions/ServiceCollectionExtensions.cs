﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Irlca.Bff.UserProfiles.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddUserProfilesGraphQL(this IServiceCollection services, IHostEnvironment environment)
    {
        services
            .AddGraphQLServer("UserProfiles")
            .AllowIntrospection(environment.IsDevelopment())
            .AddQueryType<UserProfilesQuery>();

        return services;
    }
}
