﻿#pragma warning disable S2094
namespace Irlca.Bff.Shared;

public class GetInspectionAgencyProfileResponse : GetTenantProfileResponse
{
    public static GetInspectionAgencyProfileResponse FromTenantProfileResponse(GetTenantProfileResponse tenantProfile) =>
        new()
        {
            TenantId = tenantProfile.TenantId,
            Name = tenantProfile.Name,
            Reference = tenantProfile.Reference,
            WebAddress = tenantProfile.WebAddress,
            Address = tenantProfile.Address,
            PrimaryContact = tenantProfile.PrimaryContact,
        };
}
