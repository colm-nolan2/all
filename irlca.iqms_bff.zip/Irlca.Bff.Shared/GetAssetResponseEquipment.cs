﻿namespace Irlca.Bff.Shared;

public partial class GetAssetResponseEquipment : ICreatedById
{
}
