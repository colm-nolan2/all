﻿namespace Irlca.Bff.Shared;

public partial class GetDocumentDetailsResponse : ICreatedById
{
}
