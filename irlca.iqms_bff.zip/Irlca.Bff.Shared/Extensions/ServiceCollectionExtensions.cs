﻿using System.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Irlca.Bff.Shared.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddIqmsApi(this IServiceCollection services, IConfiguration configuration)
    {
        var iqmsApiUrl = configuration["ConnectionStrings:IqmsApiUrl"] ?? throw new ConfigurationErrorsException("iQMS API URL not set");

        services
            .AddHttpClient<IIqmsClient, BffIqmsClient>("Iqms", c => c.BaseAddress = new Uri(iqmsApiUrl))
            .AddHeaderPropagation();

        return services;
    }
}
