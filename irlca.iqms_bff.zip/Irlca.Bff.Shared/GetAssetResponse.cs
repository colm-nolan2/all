﻿namespace Irlca.Bff.Shared;

public partial class GetAssetResponse : ICreatedById
{
}
