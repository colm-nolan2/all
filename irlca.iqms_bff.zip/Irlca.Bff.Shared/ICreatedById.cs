﻿namespace Irlca.Bff.Shared;

public interface ICreatedById
{
    public Guid CreatedById { get; }
}
