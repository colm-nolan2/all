﻿namespace Irlca.Bff.Shared;

public partial class GetInspectionEventsResponse
{
    public Guid InspectionId { get; set; }
}
