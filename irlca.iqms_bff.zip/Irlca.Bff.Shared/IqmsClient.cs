﻿namespace Irlca.Bff.Shared;

public partial class IqmsClient
{
    public async Task<GetChildCommentResponse> GetChildCommentAsync(Guid commentId, CancellationToken cancellationToken)
    {
        var response = await GetCommentAsync(commentId, cancellationToken);

        return GetChildCommentResponse.FromCommentResponse(response);
    }
}
