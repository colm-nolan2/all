﻿namespace Irlca.Bff.Shared;

public partial interface IIqmsClient
{
    Task<GetChildCommentResponse> GetChildCommentAsync(Guid commentId, CancellationToken cancellationToken);
}
