﻿namespace Irlca.Bff.Shared;

public partial class GetInspectorReportResponse
{
    public Guid InspectionId { get; set; }
}
