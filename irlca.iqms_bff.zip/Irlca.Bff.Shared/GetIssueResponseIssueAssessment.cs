﻿namespace Irlca.Bff.Shared;

public partial class GetIssueResponseIssueAssessment : ICreatedById
{
}
