﻿namespace Irlca.Bff.Shared;

public partial class GetInspectionAreaSnapshotResponse
{
    public Guid InspectionId { get; set; }
}
