﻿namespace Irlca.Bff.Shared;

public partial class GetInspectionAreaRoleResponse
{
    public Guid InspectionAreaId { get; set; }
}
