﻿namespace Irlca.Bff.Shared;

public partial class GetInspectionAreaRolesResponse
{
    public Guid InspectionAreaId { get; set; }
}
