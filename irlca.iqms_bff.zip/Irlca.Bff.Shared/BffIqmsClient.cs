﻿namespace Irlca.Bff.Shared;

public class BffIqmsClient(HttpClient httpClient) : IqmsClient(httpClient)
{
    public override async Task<GetInspectionAreaRolesResponse> GetInspectionAreaRolesAsync(Guid inspectionAreaId, CancellationToken cancellationToken)
    {
        var result = await base.GetInspectionAreaRolesAsync(inspectionAreaId, cancellationToken);

        result.InspectionAreaId = inspectionAreaId;

        return result;
    }

    public override async Task<GetInspectionAreaRoleResponse> GetInspectionAreaRoleAsync(Guid inspectionAreaId, Guid roleId, CancellationToken cancellationToken)
    {
        var result = await base.GetInspectionAreaRoleAsync(inspectionAreaId, roleId, cancellationToken);

        result.InspectionAreaId = inspectionAreaId;

        return result;
    }

    public override async Task<GetInspectionEventsResponse> GetInspectionEventsAsync(Guid inspectionId, CancellationToken cancellationToken)
    {
        var result = await base.GetInspectionEventsAsync(inspectionId, cancellationToken);

        result.InspectionId = inspectionId;

        return result;
    }

    public override async Task<GetInspectionAreaSnapshotResponse> GetInspectionAreaSnapshotAsync(Guid inspectionId, CancellationToken cancellationToken)
    {
        var result = await base.GetInspectionAreaSnapshotAsync(inspectionId, cancellationToken);

        result.InspectionId = inspectionId;

        return result;
    }

    public override async Task<GetInspectionTeamMemberResponse> GetInspectionTeamMemberAsync(Guid inspectionId, Guid teamMemberId, CancellationToken cancellationToken)
    {
        var result = await base.GetInspectionTeamMemberAsync(inspectionId, teamMemberId, cancellationToken);

        result.InspectionId = inspectionId;

        return result;
    }

    public override async Task<GetInspectorReportResponse> GetInspectorReportAsync(Guid inspectionId, CancellationToken cancellationToken)
    {
        var result = await base.GetInspectorReportAsync(inspectionId, cancellationToken);

        result.InspectionId = inspectionId;

        return result;
    }
}
