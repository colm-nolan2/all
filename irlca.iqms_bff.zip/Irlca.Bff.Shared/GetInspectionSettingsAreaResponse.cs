﻿namespace Irlca.Bff.Shared;

public class GetInspectionSettingsAreaResponse : GetInspectionAreaResponse
{
    public static GetInspectionSettingsAreaResponse FromInspectionArea(GetInspectionAreaResponse response) =>
        new()
        {
            Id = response.Id,
            Name = response.Name,
        };
}
