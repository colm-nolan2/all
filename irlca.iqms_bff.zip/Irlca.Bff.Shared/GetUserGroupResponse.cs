﻿namespace Irlca.Bff.Shared;

public partial class GetUserGroupResponse : ICreatedById
{
}
