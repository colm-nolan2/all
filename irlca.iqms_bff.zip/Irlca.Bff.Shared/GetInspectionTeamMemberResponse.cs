﻿namespace Irlca.Bff.Shared;

public partial class GetInspectionTeamMemberResponse
{
    public Guid InspectionId { get; set; }
}
