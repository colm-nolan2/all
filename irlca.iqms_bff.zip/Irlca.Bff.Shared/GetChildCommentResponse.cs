﻿namespace Irlca.Bff.Shared;

public class GetChildCommentResponse : GetCommentResponse
{
    public static GetChildCommentResponse FromCommentResponse(GetCommentResponse response) =>
        new()
        {
            Id = response.Id,
            AuthorId = response.AuthorId,
            ChildCommentIds = Array.Empty<Guid>(),
            Content = response.Content,
            CreatedDate = response.CreatedDate,
            Status = response.Status,
        };
}
